import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.Iterator;
public class HMTest<T> {
	@Test
	public void hashMapTest1() {
		MyHashMap<Integer> testQueue = new MyHashMap<Integer>("Cozmo",65303440);
		assertEquals(65303440, testQueue.get("Cozmo"),"Wrong Value");
		assertEquals(1, testQueue.size(), "Wrong size");
	}
	@Test 
	public void hashMapTest2() {
		MyHashMap<Integer> testQueue = new MyHashMap<Integer>("a",1);
		assertEquals(false, testQueue.isEmpty(),"No Value");
	}
	@Test
	public void hashMapTest3() {
		MyHashMap<Integer> testQueue = new MyHashMap<Integer>("a",1);
		assertEquals(1, testQueue.get("a"),"Not in 1");
	}
	@Test 
	public void hashMapTest4() {
		MyHashMap<Integer> testQueue = new MyHashMap<Integer>("a",1);
		assertEquals(1, testQueue.get("a"),"Not in 1");
		testQueue.replace("a", 10);
		assertEquals(10, testQueue.get("a"),"Not in 10");
	}
	
	@Test
	public void hashMapTest5() {
		MyHashMap<Integer> testQueue = new MyHashMap<Integer>("a",1);
		testQueue.put("b", 2);
		testQueue.put("c",3);
		testQueue.put("d", 4);
		assertEquals(4, testQueue.size(), "Wrong size");
		
	}
	@Test 
	public void hashMapTest6() {
		MyHashMap<Integer> testQueue = new MyHashMap<Integer>("a",1);
		Iterator test = testQueue.iterator();
		while(testQueue.hasNext()) {
			System.out.println("Value: "+ test.next());
		}
	}
}
