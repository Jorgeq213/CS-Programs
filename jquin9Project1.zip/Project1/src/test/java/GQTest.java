import static org.junit.jupiter.api.Assertions.*;

import java.util.Iterator;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class GQTest {
	private GenericQueue<String> newQueue;
	@BeforeEach
	public void initialize() {
		newQueue = new GenericQueue<>("One");
	}
	@Test
	public void constructortest() {
		assertEquals("One", newQueue.dequeue(),"It got deleted");
	}
	@Test 
	public void testDequeue() {
		newQueue = new GenericQueue<>("Delete");
		newQueue.delete();
		assertNull(newQueue.dequeue(),"Not deleted");
	}
	@Test
	public void testEnqueue() {
		newQueue.enqueue("Two");
		newQueue.enqueue("Three");
		assertEquals("One", newQueue.dequeue());
        assertEquals("Two", newQueue.dequeue());
        assertEquals("Three", newQueue.dequeue());
	}
	@Test 
	public void testDelete() {
		assertEquals("One", newQueue.delete());
        assertNull(newQueue.delete());
	}
	@Test
    public void testIterator() {
        newQueue.enqueue("Two");
        newQueue.enqueue("Three");
        StringBuilder result = new StringBuilder();
        Iterator<String> test = newQueue.iterator();
        while (test.hasNext()) {
        	result.append(test.next());
        }
        assertEquals("OneTwoThree", result.toString());
    }
	@Test
    public void testReverseIteration() {
        GenericQueue<Integer> list = new GenericQueue<>(10);
        list.add(23);
        list.add(02);
        Iterator<Integer> reverseIterator = list.descendingIterator();
        assertTrue(reverseIterator.hasNext());
        assertEquals(02, reverseIterator.next());
        assertTrue(reverseIterator.hasNext());
        assertEquals(23, reverseIterator.next());
        assertTrue(reverseIterator.hasNext());
        assertEquals(10, reverseIterator.next());
        assertFalse(reverseIterator.hasNext());
    }
}
