import java.util.Iterator;

public class ReverseGLLIterator<E> implements Iterator<E> {
	private GenericList<E>.Node<E> currNode;
	private GenericList<E>.Node<E> prevNode;
	public ReverseGLLIterator(GenericList<E>.Node<E> head) {
		this.currNode = head;
		this.prevNode = null;
		while(currNode != null) {
			GenericList<E>.Node<E> temp = currNode.next;
			currNode.next = prevNode;
			prevNode = currNode;
			currNode = temp;
		}
		this.currNode = prevNode;
	}
	public boolean hasNext() {
		return currNode != null;
	}
	public E next() {
		E data = currNode.data;
		currNode = currNode.next;
		return data;
	}
}
