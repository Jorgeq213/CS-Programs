import java.util.ArrayList;
import java.util.Iterator;
public abstract class GenericList<T> {
	private Node<T> head;
	private int length;
	public void print() {//Prints out the values that are in the list
		if(head==null) {
			System.out.println("Empty List");
			return;
		}
		Node<T> currNode = head;
		while(currNode != null) {
			System.out.println(currNode.data);
			currNode = currNode.next;
		}
		
	}
	public abstract void add(T data);//Implemented in MyHashMap
	public abstract T delete();//Implemented in MyHashMap
	
	public ArrayList<T>dumpList(){
		ArrayList<T> newArray = new ArrayList<T>();
		Node<T>currNode = head;
		while(currNode != null) {
			newArray.add(currNode.data);
			currNode = currNode.next;
		}
		return newArray;
	}
	public T get(int index) {//gets the value from a certain index
		if (index < 0 || index >= length) {
            return null; 
        }

        Node<T> currNode = head;
        for (int i = 0; i < index; i++) {
            currNode = currNode.next;
        }

        return currNode.data;
	}
	public T set(int index, T element) {//sets the new value to a certain index
		Node<T> currNode = head;
        T temp = null;
		if (index < 0 || index >= length) {
            return null; 
        }

		else {
        for (int i = 0; i < index; i++) {
            currNode = currNode.next;
        }
        temp = currNode.data;
        currNode.data = element;
		}
		return temp;
	}
	public int getLength(){// gets the legnth from add
		return length;
	}
	public int setLength(int newLength){
		return this.length = newLength;
	}
	public Node<T> getHead(){//gets the first value of the array 
		return head;
	}
	public void setHead(Node<T> newHead){
		this.head = newHead;
	}
	public Iterator<T>descendingIterator(){//reads our array backwards
		return new ReverseGLLIterator<T>(getHead());
	}
	public Iterator<T> iterator(){
		return null;
	}
	public class Node<T>{
		T data;
		int code;
		Node<T>next;
	} 	
	
	
}
