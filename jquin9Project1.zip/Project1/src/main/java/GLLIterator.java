import java.util.Iterator;

public class GLLIterator<E> implements Iterator<E> {
private GenericList<E>.Node<E> node;
	public GLLIterator(GenericList<E>.Node<E> head) {
		node = head;
	}
	public boolean hasNext() {//check if there is another value form the current node
		return node != null;
	}
	public E next() {//finds the next value
		E data = node.data;
		node = node.next;
		return data;
	}
}
