import java.util.ArrayList;
import java.util.Iterator;

public class MyHashMap<T> implements Iterator<T>{
	ArrayList<GenericQueue<T>> map = new ArrayList<>(10);
	public MyHashMap(String key, T value) {//applies the put method
		for(int i = 0; i<10; i++) {
			map.add(null);
		}
		put(key,value);
	}
	public void put(String key, T value) {//puts the value into a certain key
		int valueArray = key.hashCode();
		int valueIndex = valueArray&9;
		if(map.get(valueIndex) == null) {
			GenericQueue<T> help = new GenericQueue<T>(value);
			help.getHead().code = valueArray;
			map.set(valueIndex, help);
		}
		else {
			if(contains(key)) {
			replace(key,value);
			}
			else {
				map.get(valueIndex).add(value,valueArray);
			}
		}
		
	}
	public T get(String key) {//gets the value of the specific key
		int keyHash = key.hashCode()&9;
		int keyCode = key.hashCode();
		if(map.get(keyHash).getHead()==null) {
			return null;
		}
		GenericList<T>.Node<T> headNode = map.get(keyHash).getHead();
		while(headNode != null) {
			if(headNode.code == keyCode) {
				return headNode.data;
			}
			headNode = headNode.next;
		}
		return(T)null;
	}
	public boolean contains(String key) {
		int valueHash = key.hashCode();
		int valueIndex = key.hashCode()%9;
		GenericList<T>.Node<T> headNode = map.get(valueIndex).getHead();
		while(headNode != null) {
			if(headNode.code == valueHash) {
				return true;
			}
			headNode = headNode.next;
		}
		return false;
	}
	
	public int size() {
		int total = 0;
		for(int i = 0; i<10; i++) {
			if(map.get(i)!= null) {
				total += map.get(i).getLength();
			}
		}
		return total;
	}
	
	public boolean isEmpty() {//checks to see if HashMap is empty
		for(int i =0; i<10; i++) {
			if(map.get(i)!= null) {
				return false;
			}
		}
		return true;
	}
	public T replace(String key, T value) {//replaces values of a certain key
		int repValue = key.hashCode();
		int keyIndex = key.hashCode()&9;
		T nullValue = null;
		GenericList<T>.Node<T> removeNode = map.get(keyIndex).getHead();
		while(removeNode != null) {
			if(removeNode.code == repValue) {
				nullValue = removeNode.data;
				removeNode.data = value;
				break;
			}
			removeNode = removeNode.next;
		}
		return nullValue;
	}
	public Iterator<T>iterator(){
		return null;
	}
	@Override
	public boolean hasNext() {
		return false;
	}
	@Override
	public T next() {
		return null;
	}
	
}
