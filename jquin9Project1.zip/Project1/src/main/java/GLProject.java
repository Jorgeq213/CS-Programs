//Jorge Quintero
//jquin9
//jquin9@uic.edu
//In this project we are implementing a HashMap using linked lists and array lists.
//It then turns that into a map using the various hash values and hash codes. To be able to 
//access all the values. We are able to add values, delete values, as well as replace values in the hash map
//Then there are iterators to go through our Generic List forwards and reverse.

public class GLProject {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Welcome to project 1");
		
	}
}
