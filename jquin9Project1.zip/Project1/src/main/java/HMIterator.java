import java.util.Iterator;

public class HMIterator<E> implements Iterator<E> {
	private MyHashMap<E> hashMap;
	private int currPos;
	private GLLIterator<E> QI;
	public HMIterator(MyHashMap<E> hashMap) {
		this.hashMap = hashMap;
		this.currPos = 0;
		this.QI = null;
	}
	@Override
	public  boolean hasNext() {//checks if there is a value in the next key
		while(currPos < 10) {
			if(hashMap.map.get(currPos)!= null) {
				if(QI == null) {
					QI = new GLLIterator<>(hashMap.map.get(currPos).getHead());
				}
				return true;
			}
			currPos++;
		}
		return false;
	}
	@Override
	public E next() {//sets the value to next
		if(!QI.hasNext()) {
			GLLIterator<E> helper = QI;
			QI = null;
			currPos++;
			return helper.next();
		}
		return QI.next();
	}
}
