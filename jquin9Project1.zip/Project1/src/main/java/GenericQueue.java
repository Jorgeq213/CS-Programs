import java.util.Iterator;

public class GenericQueue<T> extends GenericList<T> {
	private Node<T>tail;
	public GenericQueue(T data) {//set our head node and instantiates the tail of the list
		Node<T>newNode = new Node<T>();
		newNode.data = data;
		setHead(newNode);
		tail = newNode;
		setLength(1);
	}
	@Override
	public void add(T data) {//adds to get length 
		Node<T>newNode = new Node<T>();
		newNode.data = data;
		if(getHead() == null) {
			setHead(newNode);
			tail = newNode;
		}
		else {
			tail.next = newNode;
			tail = newNode;
		}
		setLength(getLength()+1);
	}
	public void add(T data, int newCode) {//Here we have a similar implementation we also use to get length
		Node<T>currNode = new Node<T>();
		currNode.data = data;
		currNode.code = newCode;
		if(getHead()== null) {
			setHead(currNode);
			tail = currNode;
		}
		else {
			tail.next = currNode;
			tail = currNode;
		}
		setLength(getLength()+1);
	}
	public void enqueue(T data) {//applies the method add
        add(data);
    }
	@Override
	public T delete() {//method to delete the node at the end of the list
		Node<T>newNode = new Node<T>();
		
		if(getHead() == null) {
			return null;
		}
		else if(getHead() == tail) {
			newNode = getHead();
			setHead(null);
			tail = null;
		}
		else {
			newNode = getHead();
			setHead(getHead().next);
		}
			setLength(getLength()-1);
			return newNode.data;
	}
	

	public T dequeue() {//applies the delete method
		T value = delete();
		return value;
	}
	@Override
	public Iterator<T>iterator(){//iterates through list backwards
		return new GLLIterator<T>(getHead());
	
	}
}
