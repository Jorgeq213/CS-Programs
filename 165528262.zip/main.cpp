#include <iostream>
#include <vector>
#include "mymatrix.h"
using namespace std;

bool testCase1(){
    mymatrix<int> matrix(5,3);
    if(matrix.numrows() != 5){
        cout << "Test Failed" << endl;
        return false;
    }
    for(int i = 0; i < matrix.numrows(); i++){
        if(matrix.numcols(i) != 3){
            cout << "test failed" << endl;
            return false;
        }
    }
    cout << "Test Passed" << endl;
    return true;
}
bool testCase1_5(){
    mymatrix<double> matrix(5.0,3.0);
    if(matrix.numrows() != 5.0){
        cout << "Test Failed" << endl;
        return false;
    }
    for(int i = 0; i < matrix.numrows(); i++){
        if(matrix.numcols(i) != 3.0){
            cout << "test failed" << endl;
            return false;
        }
    }
    cout << "Test Passed" << endl;
    return true;
}
bool testCase2(){
     mymatrix<int> matrix(4,4);
    if(matrix.numrows() != 4){
        cout << "Test Failed" << endl;
        return false;
    }
    else{
        cout << "Test Passed" << endl;
        return true;
    }
}
bool testCase3(){
     mymatrix<double> matrix(4.0,4.0);
    if(matrix.numrows() != 4.0){
        cout << "Test Failed" << endl;
        return false;
    }
    else{
        cout << "Test Passed" << endl;
        return true;
    }
}
bool testCase4(){
    mymatrix<int> matrix(3,3);
    matrix(0,0) = 0;
    matrix(1,1) = 1;
    matrix(2,2) = 2;
    if(matrix.at(1,1) != 1){
        cout << "Test Failed" << endl;
        return false;
    }
    return true;
}
bool testCase5(){
    mymatrix<int> matrix(5,5);
    if(matrix.size() != 25){
        cout << "Test Failed" << endl;
        return false;
    }
    return true;
}
bool testCase6(){
    mymatrix<int> matrix(6,6);
    if(matrix.size() != 36){
        cout << "Test Failed" << endl;
    }
    return true;
}
bool testCase7(){
    mymatrix<int> matrix(1,1);
    matrix.grow(2,2);
    if(matrix.size()!=4){
        cout << "Test Failed" << endl;
        return false;
    }
    return true;
}
bool testCase8(){
    mymatrix<double> matrix(1.0,1.0);
    matrix.grow(2.0,2.0);
    if(matrix.size()!=4.0){
        cout << "Test Failed" << endl;
        return false;
    }
    return true;
}
 bool testCase9(){
    mymatrix<int> matrix(4,4);
    int grow = 6;
    for(int i = 0; i <matrix.numrows(); i++){
        matrix.growcols(i, grow);
    }
    for(int i = 0; i < matrix.numrows(); i++){
        if(matrix.numcols(i) == grow){
            return true;
        }
        else{
            return false;
        }
    }
 }
 bool testCase10(){
    mymatrix<double> matrix(4.0,4.0);
    int grow = 6.0;
    for(int i = 0.0; i <matrix.numrows(); i++){
        matrix.growcols(i, grow);
    }
    for(int i = 0.0; i < matrix.numrows(); i++){
        if(matrix.numcols(i) == grow){
            return true;
        }
        else{
            return false;
        }
    }
 }



int main(){
int passedTest = 0;
int failedTest = 0;
if(testCase1() == true){
passedTest++;
}
else{
failedTest++;
}
if(testCase1_5() == true){
passedTest++;
}
else{
    failedTest++;
}
if(testCase2() == true){
passedTest++;
}
else{
    failedTest++;
}
if(testCase3() == true){
passedTest++;
}
else{
    failedTest++;
}
if(testCase4() == true){
passedTest++;
}
else{
    failedTest++;
}
if(testCase5() == true){
passedTest++;
}
else{
   failedTest++; 
}
if(testCase6() == true){
passedTest++;
}
else{
    failedTest++;
}
if(testCase7() == true){
passedTest++;
}
else{
    failedTest++;
}
if(testCase8() == true){
passedTest++;
}
else{
    failedTest++;
}
if(testCase9() == true){
passedTest++;
}
else{
    failedTest++;
}
if(testCase10() == true){
passedTest++;
}
else{
    failedTest++;
}


cout << "Passed Tests " << passedTest << endl;
cout << "Failed Tests " << failedTest << endl;
}