
/*
Jorge Quintero
Program 3 Twenty-four part two
VSCode Windows 11
Prof: Kidane
Went to OH hours
*/
#include <stdio.h>
#include <time.h>
#include <string.h>
#include <math.h>
#include <ctype.h>
#include <stdlib.h>

#define MAX_SIZE 100

struct node
{
  float pValue;
  struct node *pNext;
};

//reads in easy.txt file
void easyFile(int **numArrays, int *position)
{
  int num = 0;
  *position = 0;
  char filename[] = "easy.txt";
  FILE *openFile = fopen(filename, "r");
  if (openFile == NULL)
  {
    printf("Error: could not open %s for reading\n", filename);
    exit(-1);
  }
  char input[10];
  while (fscanf(openFile, "%s", input) != EOF)
  {
    numArrays[*position][num] = atoi(input);
    num++;
    if (num == 4)
    {
      num = 0;
      (*position)++;
    }
  }
  fclose(openFile);
}
//reads in medium.txt
void mediumFile(int **numArray, int *position)
{
  int num = 0;
  *position = 0;
  char filename[] = "medium.txt";
  FILE *openFile = fopen(filename, "r");
  if (openFile == NULL)
  {
    printf("Error: could not open %s for reading\n", filename);
    exit(-1);
  }
  char input[10];
  while (fscanf(openFile, "%s", input) != EOF)
  {
    numArray[*position][num] = atoi(input);
    num++;
    if (num == 4)
    {
      num = 0;
      (*position)++;
    }
  }
  fclose(openFile);
}
//reads in hard.txt file
void hardFile(int **numArray, int *position)
{
  int num = 0;
  *position = 0;
  char filename[] = "hard.txt";
  FILE *openFile = fopen(filename, "r");

  if (openFile == NULL)
  {
    printf("Error: could not open %s for reading\n", filename);
    exit(-1);
  }
  char input[10];
  while (fscanf(openFile, "%s", input) != EOF)
  {
    numArray[*position][num] = atoi(input);
    num++;
    if (num == 4)
    {
      num = 0;
      (*position)++;
    }
  }
  fclose(openFile);
}
//Function to add a value to the top of a stack
void add(int input, struct node** pFirst)
{
  struct node *pNew = (struct node *)malloc(sizeof(struct node));
  pNew->pValue = input;
  pNew->pNext = *pFirst;
  *pFirst = pNew;
}
// Function to remove and return the top value from a stack
float pop(struct node** pFirst)
{
  if (*pFirst == NULL)
  {
    exit(1);
  }
  else
  {
    struct node *temp = *pFirst;
    float item = temp->pValue;
    *pFirst = temp->pNext;
    free(temp);
    return item;
  }
}
void freeStack(struct node** pFirst){
  while(*pFirst != NULL){
    pop(pFirst);
  }
}
// Function to check if a character is an operator (+, -, *, or /)
int operatorCheck(char operator)
{
  if (operator== '+' || operator== '-' || operator== '*' || operator== '/')
  {
    return 1;
  }
  else
  {
    return 0;
  }
}
// This function returns the priority of an operator based on the order of operations.
int pemdas(char operator)
{
  if (operator== '*' || operator== '/')
  {
    return 2;
  }
  else if (operator== '+' || operator== '-')
  {
    return 1;
  }
  else
  {
    return 0;
  }
}
// This function converts an infix expression to postfix notation.
void infixConvert(char infix[], char postfix[], struct node** pFirst)
{
  int i = 0;
  int j = 0;
  char brace;
  char x;

  add('(', pFirst);
  strcat(infix, ")");
  brace = infix[i];

  while (i < strlen(infix))
  {
    if (brace == '(')
    {
      add(brace, pFirst);
    }
    else if (isdigit(brace))
    {
      postfix[j] = brace;
      j++;
    }
    else if (operatorCheck(brace) == 1)
    {
      x = pop(pFirst);
      while (operatorCheck(x) == 1 && pemdas(x) >= pemdas(brace))
      {
        postfix[j] = x;
        j++;
        x = pop(pFirst);
      }

      add(x, pFirst);
      add(brace, pFirst);
    }
    else if (brace == ')')
    {
      x = pop(pFirst);
      while (x != '(')
      {
        postfix[j] = x;
        j++;
        x = pop(pFirst);
      }
    }
    else if (brace == ' ')
    {
    }
    else
    {
      printf("\nInvalid infix expression.");
      exit(1);
    }

    i++;
    brace = infix[i];
  }

  postfix[j] = '\0';
}
// This function evaluates a postfix expression and returns the result.
int postEval(char postfix[], char brace, int braceIndex, struct node** pFirst)
{
  int i = 0;
  int answer = 0;
  int symbol;
  int symbol2;
  char operator;

  while (postfix[i] != '\0')
  {
    operator= postfix[i];

    if (postfix[i] == brace && i == braceIndex)
    {
      answer = pop(pFirst);
      return answer;
    }
    if(isdigit(operator)){
      add(operator - '0', pFirst);
    }
    else if (operatorCheck(operator) == 1)
    {
      symbol2 = pop(pFirst);
      symbol = pop(pFirst);
      switch (operator)
      {
      case '+':
        answer = symbol + symbol2;
        printf("%d + %d = %d.\n", symbol, symbol2, answer);
        break;
      case '-':
        answer = symbol - symbol2;
        printf("%d - %d = %d.\n", symbol, symbol2, answer);
        break;
      case '*':
        answer = symbol * symbol2;
        printf("%d * %d = %d.\n", symbol, symbol2, answer);
        break;
      case '/':
        answer = symbol / symbol2;
        printf("%d / %d = %d.\n", symbol, symbol2, answer);
        break;
      }
      add(answer, pFirst);
    }
    i++;
  }

  answer = pop(pFirst);
  return answer;
}
// This function checks if a set of numbers contains each number only once.
int numCheck(char *numArray, int num1, int num2, int num3, int num4)
{
  int numCount = 0;
  int val1 = 0;
  int val2 = 0;
  int val3 = 0;
  int val4 = 0;
  for (int i = 0; i < 4; i++)
  {
    int num = numArray[i] - '0';
    if (num == num1 && val1 == 0)
    {
      numCount++;
      val1 = 1;
    }
    else if (num == num2 && val2 == 0)
    {
      numCount++;
      val2 = 1;
    }
    else if (num == num3 && val3 == 0)
    {
      numCount++;
      val3 = 1;
    }
    else if (num == num4 && val4 == 0)
    {
      numCount++;
      val4 = 1;
    }
  }
  return (numCount == 4);
}
// This function checks if the input contains only valid symbols and uses each number once.
void validInput(char *inputArray, int num1, int num2, int num3, int num4, int *pass)
{
  int numCount = 0;
  char nums[10];

  for (int i = 0; i < strlen(inputArray); i++)
  {
    if (isdigit(inputArray[i]))
    {
      nums[numCount] = inputArray[i];
      numCount++;
    }
    if (isdigit(inputArray[i]) == 0 && inputArray[i] != '-' && inputArray[i] != '+' && inputArray[i] != ' ' &&
        inputArray[i] != '*' && inputArray[i] != '/' && inputArray[i] != '(' && inputArray[i] != ')')
    {
      printf("Error! Invalid symbol entered. Please try again.\n");
      *pass = 0;
      return;
    }
  }
  if (numCount < 4 || numCount > 4 || numCheck(nums, num1, num2, num3, num4) == 0)
  {
    printf("Error! You must use all four numbers, and use each one only once. Please try again.\n");
    *pass = 0;
    return;
  }
  *pass = 1;
}
// This function checks if the input contains exactly three operators.
int symbolCheck(char *symArray)
{
  int count = 0;
  for (int i = 0; i < strlen(symArray); i++)
  {
    if (symArray[i] == '-' || symArray[i] == '+' || symArray[i] == '/' || symArray[i] == '*')
    {
      count++;
    }
  }

  if (count != 3)
  {
    return 0;
  }
  return 1;
}
// This function prints a message based on whether the result is 24 or not.
void endGame(int num)
{
  if (num == 24)
  {
    printf("Well done! You are a math genius.\n");
  }
  else
  {
    printf("Sorry. Your solution did not evaluate to 24.\n");
  }
}
// This function removes a specified parenthesis from a string.
void removePar(char *brace, char par)
{
  int i;
  int j;
  int position = 0;
  for (i = strlen(brace); i != 0; i--)
  {
    if (brace[i] == par)
    {
      position = i;
      break;
    }
  }
  memmove(&brace[position], &brace[position + 1], strlen(brace) - position);
}
// This function checks if a string has an even number of parentheses and removes any extra ones.
int parEval(char *brace)

{
  int size = strlen(brace);
  int count = 0;
  int evenPar = 1;
  for (int i = strlen(brace) - 1; i >= 0; i--)
  {
    if (brace[i] == '(')
    {
      count++;
    }
    else if (brace[i] == ')')
    {
      count--;
    }
  }

  while (count > 0 || count < 0)
  {
    evenPar = 0;
    if (count < 0)
    {
      removePar(brace, ')');
      count++;
    }
    else
    {
      removePar(brace, '(');
      count--;
    }
  }

  return evenPar * (count == 0);
}
int evenPar(char *brace) {
  int size = strlen(brace);
  int count = 0;
  int evenPar = 1;

  for (int i = strlen(brace) - 1; i >= 0; i--) {
    if (brace[i] == '(') {
      count++;
    } else if (brace[i] == ')') {
      count--;
    }
  }

  return count;
}
char parStop(char *brace, int *position) {
  int count = 0;
  int size = strlen(brace);
  int x = 0;

  count = evenPar(brace);
  if (count != 0) {
    for (int i = 0; i < strlen(brace); i++) {
      if (brace[i] == '(') {
        count = 1;
      } else if (brace[i] == ')') {
        if (count == 1) {
          count = 0;
        } else {
          //printf("i: %d\n", i);
          *position = i;
          for (x = *position; x < strlen(brace); x++) {
            if (isdigit(brace[x])) {
              size = x;
              break;
            }
            
          }
          int counter = 0;
          for (int j = 0; j <= (size); j++) {
            if (isdigit(brace[j])) {
              counter++;
            }
          }
          if (counter == 1) {
            *position = 0;
          }
          if (counter == 2) {
            *position = 1;
          }
          if (counter == 3) {
            *position = 3;
          }
          if (counter == 4) {
            *position = 5;
          }
          return brace[size];
        }
      }
    }
  }
  else {
    return 'a';
  }
}


int main()
{
  char userInput = '2'; // initialize user input to any non-1 value
  char gameMode; // store difficulty level: E, M, or H
  int numGen = 0; // random number generator seed
  struct node* pFirst = NULL;
  int size = 0; // size of the array of number sets
  char c = ' ';
  int num1 = 0;
  int num2 = 0;
  int num3 = 0;
  int num4 = 0;
  char solvedArray[100];
  char infix[100];
  char postfix[100];
  int answer;
  char num = 'a';
  int lastNum = 100;
  int condition = 0;
  int condition2 = 0;
  int condition3 = 0;
  int **numArray; // array of number sets for easy mode
  int **numArrayH; // array of number sets for hard mode
  int **numArrayM; // array of number sets for medium mode
  // allocate memory for number sets
  numArray = malloc(sizeof(int *) * 50);
  for (int i = 0; i < 50; i++)
  {
    numArray[i] = malloc(sizeof(int) * 4);
  }
  numArrayM = malloc(sizeof(int *) * 50);
  for (int i = 0; i < 50; i++)
  {
    numArrayM[i] = malloc(sizeof(int) * 4);
  }
  numArrayH = malloc(sizeof(int *) * 50);
  for (int i = 0; i < 50; i++)
  {
    numArrayH[i] = malloc(sizeof(int) * 4);
  }

  // seed the random number generator
  //srand(1);

  // welcome message and game instructions
  srand(1);
  printf("Welcome to the game of TwentyFour Part Two!\n");
  printf("Use each of the four numbers shown exactly once, \n");
  printf("combining them somehow with the basic mathematical operators (+,-,*,/) \n");
  printf("to yield the value twenty-four.\n");

  while (userInput == '1' || userInput == '2')
  {
    if (userInput == '1')
    {
       // generate numbers for the game based on difficulty level
      if (gameMode == 'H')
      {
        numGen = (rand() % size);
        num1 = numArrayH[numGen][0];
        num2 = numArrayH[numGen][1];
        num3 = numArrayH[numGen][2];
        num4 = numArrayH[numGen][3];
      }
      else if (gameMode == 'M')
      {
        numGen = (rand() % size);
        num1 = numArrayM[numGen][0];
        num2 = numArrayM[numGen][1];
        num3 = numArrayM[numGen][2];
        num4 = numArrayM[numGen][3];
      }
      else
      {
        numGen = (rand() % size);
        num1 = numArray[numGen][0];
        num2 = numArray[numGen][1];
        num3 = numArray[numGen][2];
        num4 = numArray[numGen][3];
      }
      printf("The numbers to use are: %d, %d, %d, %d.\n", num1, num2, num3, num4);
      printf("Enter your solution: ");
      fgets(solvedArray, sizeof(solvedArray), stdin);
      if (strcmp(solvedArray, "\n") == 0)
      {
        fgets(solvedArray, sizeof(solvedArray), stdin);
      }
      solvedArray[strcspn(solvedArray, "\n")] = '\0';
      num = parStop(solvedArray, &lastNum);
      // Check if the input is valid
      condition2 = parEval(solvedArray);
      condition3 = symbolCheck(solvedArray);
      validInput(solvedArray, num1, num2, num3, num4, &condition);

      if (condition)
      {
       infixConvert(solvedArray, postfix, &pFirst); // Convert the input to postfix notation
      answer = postEval(postfix, num, lastNum, &pFirst); // Evaluate the postfix expression
      if (condition2 == 1 && condition3 == 1) // Check if the input has the correct number of parentheses and operators
        {
          endGame(answer);
        }
      }
      else
      {
        userInput = '1';
        continue;
      }
      if (!condition2)
      {
        printf("Error! Too many closing parentheses in the expression.\n");
      }
      else if (!condition3)
      {
        printf("Error! Too many values in the expression.\n");
      }
    }
    else if (userInput == '2')
    {
      printf("Choose your difficulty level: E for easy, M for medium, and H for hard (default is easy).\n");
      printf("Your choice --> ");
      scanf("%c", &gameMode);
      // while ((c = getchar()) != '\n' && c != EOF);
      if (gameMode == '\n')
      {
        scanf("%c", &gameMode);
      }
      if (gameMode == 'H')
      {
        hardFile(numArrayH, &size);
        numGen = (rand() % size);
        num1 = numArrayH[numGen][0];
        num2 = numArrayH[numGen][1];
        num3 = numArrayH[numGen][2];
        num4 = numArrayH[numGen][3];
      }
      else if (gameMode == 'M')
      {
        mediumFile(numArrayM, &size);
        numGen = (rand() % size);
        num1 = numArrayM[numGen][0];
        num2 = numArrayM[numGen][1];
        num3 = numArrayM[numGen][2];
        num4 = numArrayM[numGen][3];
      }
      else
      {
        easyFile(numArray, &size);

        numGen = (rand() % size);
        num1 = numArray[numGen][0];
        num2 = numArray[numGen][1];
        num3 = numArray[numGen][2];
        num4 = numArray[numGen][3];
      }
      printf("The numbers to use are: %d, %d, %d, %d.\n", num1, num2, num3, num4);
      printf("Enter your solution: ");
      fgets(solvedArray, sizeof(solvedArray), stdin);
      // If the user only pressed the Enter key, prompt again for input
      if (strcmp(solvedArray, "\n") == 0)
      {
        fgets(solvedArray, sizeof(solvedArray), stdin);
      }
      // Remove the newline character at the end of the input
      solvedArray[strcspn(solvedArray, "\n")] = '\0';
      num = parStop(solvedArray, &lastNum);
      // Remove the newline character at the end of the input
      condition2 = parEval(solvedArray);
      condition3 = symbolCheck(solvedArray);
      validInput(solvedArray, num1, num2, num3, num4, &condition);
      if (condition)
      {
        infixConvert(solvedArray, postfix, &pFirst); // Convert the input to postfix notation
      answer = postEval(postfix, num, lastNum, &pFirst); // Evaluate the postfix expression
      if (condition2 == 1 && condition3 == 1) // Check if the input has the correct number of parentheses and operators
        {
          endGame(answer);
        }
      }
      else
      {
        userInput = '1';
        continue;
      }
      if (!condition2)
      {
        printf("Error! Too many closing parentheses in the expression.\n");
        
      }
      else if (!condition3)
      {
        printf("Error! Too many values in the expression.\n");
        
      }
    }
    // Takes player to restart menu to select
    printf("\nEnter: \t1 to play again,\n");
    printf("\t2 to change the difficulty level and then play again, or\n");
    printf("\t3 to exit the program.\n");
    printf("Your choice --> ");
    scanf("%c", &userInput);
  }

  printf("\nThanks for playing!\n");
  printf("Exiting...\n");
//free the memory of the array used*
  for (int i = 0; i < 50; i++)
  {
    free(numArray[i]);
    free(numArrayM[i]);
    free(numArrayH[i]);
  }
  free(numArray);
  free(numArrayM);
  free(numArrayH);

  freeStack(&pFirst);
  free(pFirst);

  return 0;
}