import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.junit.jupiter.api.DisplayName;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class MyTest {
	private Card card;
	private BaccaratDealer dealer;
	private BaccaratDealer dealer2;
	private BaccaratGameLogic gameLogic;
	private BaccaratGame game;
	@BeforeEach
    public void setUpCard() {
        card = new Card("Hearts", 1);
    }

    @BeforeEach
    public void setUpDealer() {
        dealer = new BaccaratDealer();
        dealer2 = new BaccaratDealer();
    }
    @BeforeEach
    public void setUpLogic() {
        gameLogic = new BaccaratGameLogic();
    }
//    @BeforeEach
//    public void setup() {
//        game = new BaccaratGame();
//    }
    @Test
    public void testConstructor() {
        // Since 'suite' and 'value' are package-private, we can access them directly here
        assertEquals("Hearts", card.suite, "Wrong suite");
        assertEquals(1, card.value, "Wrong Value");
    }
    @Test
    public void testDeckSize() {
        assertEquals(52, dealer.getDeck().size(), "Size not 52.");
    }

    @Test
    public void testDeckCards() {
        Set<Card> uniqueCards = new HashSet<>(dealer.getDeck());
        assertEquals(52, uniqueCards.size(), "Card not Unique.");
    }
    @Test
    public void testGenerateDeckUnique() {
        dealer.generateDeck();
        dealer2.generateDeck();
        boolean differentOrder = false;
        for (int i = 0; i < 5; i++) {
            if (!dealer.getDeck().get(i).equals(dealer2.getDeck().get(i))) {
                differentOrder = true;
                break;
            }
        }
        assertTrue(differentOrder, "Cards are all different");
    }
    @Test
    public void testGenerateDeckSize() {
        dealer.generateDeck();
        assertEquals(52, dealer.getDeck().size(), "Size is not 52");
    }
    @Test
    public void testDealHandSize() {
        ArrayList<Card> hand = dealer.dealHand();
        assertEquals(2, hand.size(), "There is more than two cards.");
    }
    @Test
    public void testDealHandAfter() {
        int initialSize = dealer.getDeck().size();
        dealer.dealHand();
        assertEquals(initialSize - 2, dealer.getDeck().size(), "The size didn't drop 2");
    }
    @Test
    public void testDrawOneNotSame() {
        Card drawnCard = dealer.drawOne();
        assertFalse(dealer.getDeck().contains(drawnCard), "The card is not the same.");
    }

    @Test
    public void testDrawOneSize() {
        int initialSize = dealer.getDeck().size();
        dealer.drawOne();
        assertEquals(initialSize - 1, dealer.getDeck().size(), "The size is not 3");
    }
    @Test
    public void testShuffleDeckSize() {
        int initialSize = dealer.getDeck().size();
        dealer.shuffleDeck();
        assertEquals(initialSize, dealer.getDeck().size(), "The size is still the same");
    }

    @Test
    public void testShuffleDeckOrder() {
        ArrayList<Card> originalDeck = new ArrayList<>(dealer.getDeck());
        dealer.shuffleDeck();
        boolean isOrderSame = originalDeck.equals(dealer.getDeck());
        assertFalse(isOrderSame, "Deck order changed");
    }
    @Test
    public void testWhoWonPlayer() {
    	ArrayList<Card> playerHand = new ArrayList<>();
        playerHand.add(new Card("Hearts", 2));
        playerHand.add(new Card("Diamonds", 3));
        ArrayList<Card> bankerHand = new ArrayList<>();
        bankerHand.add(new Card("Clubs", 2));
        bankerHand.add(new Card("Spades", 2));
        assertEquals("Player", gameLogic.whoWon(playerHand, bankerHand));
    }
    @Test
    public void testWhoWonBanker() {
    	  ArrayList<Card> playerHand = new ArrayList<>();
          playerHand.add(new Card("Hearts", 1));
          playerHand.add(new Card("Diamonds", 2));
          ArrayList<Card> bankerHand = new ArrayList<>();
          bankerHand.add(new Card("Clubs", 3));
          bankerHand.add(new Card("Spades", 3));
          assertEquals("Banker", gameLogic.whoWon(playerHand, bankerHand));
    }
    @Test
    public void testWhoWonDraw() {
    	 ArrayList<Card> playerHand = new ArrayList<>();
         playerHand.add(new Card("Hearts", 2));
         playerHand.add(new Card("Diamonds", 3));
         ArrayList<Card> bankerHand = new ArrayList<>();
         bankerHand.add(new Card("Clubs", 4));
         bankerHand.add(new Card("Spades", 1));
         assertEquals("Tie", gameLogic.whoWon(playerHand, bankerHand));
    }
    @Test
    public void testHandTotal() {
        ArrayList<Card> hand = new ArrayList<>();
        hand.add(new Card("Hearts", 2));
        hand.add(new Card("Diamonds", 3));
        assertEquals(5, gameLogic.handTotal(hand));
    }
    @Test
    public void testHandTotalFace() {
        ArrayList<Card> hand = new ArrayList<>();
        hand.add(new Card("Hearts", 10));
        hand.add(new Card("Diamonds", 11));
        hand.add(new Card("Clubs", 12));
        hand.add(new Card("Spades", 13));
        assertEquals(0, gameLogic.handTotal(hand));
    }
    @Test
    public void testEvaluateBankerDraw() {
        ArrayList<Card> hand = new ArrayList<>();
        hand.add(new Card("Hearts", 1));
        hand.add(new Card("Diamonds", 2));
        assertTrue(gameLogic.evaluateBankerDraw(hand, new Card("Clubs", 2)));
        assertFalse(gameLogic.evaluateBankerDraw(hand, new Card("Clubs", 8)));
    }
    @Test
    public void testEvaluateBankerDraw2() {
        ArrayList<Card> hand = new ArrayList<>();
        hand.add(new Card("Hearts", 2));
        hand.add(new Card("Diamonds", 2));
        assertTrue(gameLogic.evaluateBankerDraw(hand, new Card("Clubs", 2)));
        assertFalse(gameLogic.evaluateBankerDraw(hand, new Card("Clubs", 1)));
        assertFalse(gameLogic.evaluateBankerDraw(hand, new Card("Clubs", 8)));
    }
    @Test
    public void testEvaluatePlayerDoesNotDraw() {
        ArrayList<Card> hand = new ArrayList<>();
        hand.add(new Card("Hearts", 4));
        hand.add(new Card("Diamonds", 4));
        assertFalse(gameLogic.evaluatePlayerDraw(hand)); 
        hand.clear();
        hand.add(new Card("Hearts", 2));
        hand.add(new Card("Diamonds", 7));
        assertFalse(gameLogic.evaluatePlayerDraw(hand)); 
    }
    @Test
    public void testEvaluatePlayerDrawFaces() {
        ArrayList<Card> hand = new ArrayList<>();
        hand.add(new Card("Hearts", 10));
        hand.add(new Card("Diamonds", 11));
        assertTrue(gameLogic.evaluatePlayerDraw(hand)); 
    }
    
}
