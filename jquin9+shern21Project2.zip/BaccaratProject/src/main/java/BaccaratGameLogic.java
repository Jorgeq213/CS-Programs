import java.util.ArrayList;

import javafx.animation.FadeTransition;
import javafx.animation.PauseTransition;
import javafx.animation.RotateTransition;
import javafx.animation.SequentialTransition;
import javafx.application.Application;

import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.util.Duration;


public class BaccaratGameLogic{
	
	//The method whoWon will evaluate two hands at the end of the game and return a string
	//depending on the winner: “Player”, “Banker”, “Draw”.
	public String whoWon(ArrayList<Card> playerHand, ArrayList<Card> bankerHand) {
	    int playerTotal = handTotal(playerHand);
	    int bankerTotal = handTotal(bankerHand);

	    if (playerTotal > bankerTotal) {
	        return "Player";
	    } else if (bankerTotal > playerTotal) {
	        return "Banker";
	    } else {
	        return "Tie";
	    }
	}
	//The method handTotal will take a
	//hand and return how many points that hand is worth.
	public int handTotal(ArrayList<Card> hand) {
		
	    int total = 0;
	    for (Card card : hand) {
	        if (card.value > 9) {
	            total += 0;
	        } else {
	            total += card.value;
	        }
	        
	    }
	    
	    return total % 10; // Return only the units digit
	}
	
	//The methods evaluateBankerDraw
	//and evaluatePlayerDraw will return true if either one should be dealt a third card,
	//otherwise return false.
	public boolean evaluateBankerDraw(ArrayList<Card> hand, Card playerCard) {
		
		if(handTotal(hand) == 3) {
			
			if(playerCard.value != 8) {
				
				return true;
				
			}
			
		}
		else if(handTotal(hand) == 4) {
			
			if (playerCard.value >= 2 && playerCard.value <= 7) {
				
				return true;
				
			}
			
		}
		else if(handTotal(hand) == 5) {
			
			if (playerCard.value >= 4 && playerCard.value <= 7) {
				
				return true;
				
			}
			
		}
		else if(handTotal(hand) == 6) {
			
			if (playerCard.value == 6 || playerCard.value == 7) {
				
				return true;
				
			}
			
		}

		return false;
		
	}
	
	public boolean evaluatePlayerDraw(ArrayList<Card> playerHand) {
		
	    int total = handTotal(playerHand);
	    
	    return total >= 0 && total <= 5;
	    
	}
	
}