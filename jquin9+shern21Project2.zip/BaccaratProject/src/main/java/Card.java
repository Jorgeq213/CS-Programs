

public class Card{
	
	String suite;
	
	int value;
	
	Card(String theSuite, int theValue) {
		
		this.value = theValue;
		
		this.suite = theSuite;
		
	}
	
}