import java.util.ArrayList;
import java.util.Collections;

public class BaccaratDealer{
	
	private ArrayList<Card> deck = new ArrayList<>();
	
	BaccaratDealer(){
		
		setDeck(new ArrayList<>());
		
        generateDeck();
		
	}
	
	//generateDeck will generate a new standard 52 card deck where each card is an
	//instance of the Card class in the ArrayList<Card> deck.
	public void generateDeck() {
		
		getDeck().clear();
		
		String[] suites = { "Hearts", "Diamonds", "Clubs", "Spades" };
		
        int[] values = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13 };

        for (String suite : suites) {
        	
            for (int value : values) {
            	
                Card newCard = new Card(suite, value);
                
                getDeck().add(newCard);
                
            }
            
        }
        
        shuffleDeck();
		
	}
	
	// dealHand will deal two cards
	//and return them in an ArrayList<Card>. 
	public ArrayList<Card> dealHand() {
		
		ArrayList<Card> returnHand = new ArrayList<>();
		
		returnHand.add(getDeck().get(0));
		returnHand.add(getDeck().get(1));
		
		getDeck().remove(0);
		getDeck().remove(0);
		
		return returnHand;
		
	}
	
	//drawOne will deal a single card and return it.
	public Card drawOne() {
		
		Card returnCard = getDeck().get(0);
		
		getDeck().remove(0);
		
		return returnCard;
		
	}
	
	//shuffleDeck will create a new deck of 52 cards and “shuffle”; randomize the cards in that
	//ArrayList<Card>.
	public void shuffleDeck() {
		
		Collections.shuffle(getDeck());
		
	}
	
	// deckSize will just return how many cards are in this.deck at any given time.
	public int deckSize() {
		
		return getDeck().size();
		
	}

	public ArrayList<Card> getDeck() {
		return deck;
	}

	public void setDeck(ArrayList<Card> deck) {
		this.deck = deck;
	}
}