import java.util.ArrayList;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.stage.Stage;


public class BaccaratGame extends Application {
	
	private ArrayList<Card> playerHand;
	
	private ArrayList<Card> bankerHand;
	
	private BaccaratDealer theDealer = new BaccaratDealer();
	
	private BaccaratGameLogic gameLogic = new BaccaratGameLogic();
	
	String betWho;
	
	String winner;
	
	double balance = 1000.0;
	
	double currentBet;
	
	double totalWinnings;
	
    Label playerScore = new Label();
    
    Label bankerScore = new Label();
	
    ArrayList<ImageView> cardPNGs = new ArrayList<>();
    
    Label outcomeLabel = new Label();

	Label balanceLabel = new Label();
	
	public static void main(String[] args) {
		
		launch(args);
		
	}
	
	public void PlayGame() {
	
		if(theDealer.deckSize() <= 6) {
			
			theDealer.generateDeck();
			
			theDealer.shuffleDeck();
			
		}
		
		if(playerHand != null) {
		
			playerHand.clear();
		
			bankerHand.clear();
		
		}
		
		playerHand = theDealer.dealHand();
		
		bankerHand = theDealer.dealHand();
		
		if(gameLogic.evaluatePlayerDraw(playerHand)) {
			
			playerHand.add(theDealer.drawOne());
			
		}
		
		if(playerHand.size() < 3) {
			
			if(gameLogic.handTotal(bankerHand) <= 2) {
				
				bankerHand.add(theDealer.drawOne());
				
			}
			
		}
		else if(gameLogic.evaluateBankerDraw(bankerHand, playerHand.get(2))) {
			
			bankerHand.add(theDealer.drawOne());
			
		}
		
		String winPhrase = gameLogic.whoWon(playerHand, bankerHand);
		
		
		if(winPhrase.contains("Player")) {
			
			winner = "Player";
			
		}
		else if(winPhrase.contains("Banker")) {
			
			winner = "Banker";
			
		}
		else if(winPhrase.contains("Tie")) {
	
			winner = "Tie";
	
		}
		
		// Display the card images
	    for (int i = 0; i < playerHand.size(); i++) {
	    	
	        Image img = new Image(getClass().getResourceAsStream("/Cards/" + playerHand.get(i).value + "_" + playerHand.get(i).suite + ".png"));
	        
	        cardPNGs.get(i).setImage(img);
	        
	        cardPNGs.get(i).setVisible(true);
	        
	    }

	    for (int i = 0; i < bankerHand.size(); i++) {
	    	
	        Image img = new Image(getClass().getResourceAsStream("/Cards/" + bankerHand.get(i).value + "_" + bankerHand.get(i).suite + ".png"));
	        
	        cardPNGs.get(i + 3).setImage(img);
	        
	        cardPNGs.get(i + 3).setVisible(true);
	        
	    }

	    if (playerHand.size() < 3) {
	    	
	        cardPNGs.get(2).setVisible(false);
	        
	    } else {
	    	
	        cardPNGs.get(2).setVisible(true);
	        
	    }
	    
	    if (bankerHand.size() < 3) {
	    	
	        cardPNGs.get(5).setVisible(false);
	        
	    } else {
	    	
	        cardPNGs.get(5).setVisible(true);
	        
	    }
		
		playerScore.setText("Player Score: " + gameLogic.handTotal(playerHand));
		
        bankerScore.setText("Banker Score: " + gameLogic.handTotal(bankerHand));

        evaluateWinnings();
		
	}
	
	//This method will determine if the user won or lost their bet and return the amount won or
	//lost based on the value in currentBet.
	public double evaluateWinnings() {
	
		double winnings = 0;
    
		if (betWho.equalsIgnoreCase(winner)) {
    	
			if (winner.equalsIgnoreCase("Tie")) {
        	
				winnings = currentBet * 8;

				totalWinnings += winnings;
            
				outcomeLabel.setText("It's a Tie! You won " + winnings + ". Total winnings: " + totalWinnings);
            
			} else {
        	
				winnings = currentBet;
            
            	totalWinnings += winnings;
            
            	outcomeLabel.setText("Congratulations! You won " + winnings + ". Total winnings: " + totalWinnings);
            
			}
        
		} else {
    	
			winnings -= currentBet;
        
			totalWinnings += winnings;
        
			outcomeLabel.setText("Sorry! You lost " + Math.abs(winnings) + ". Total winnings: " + totalWinnings);
        
		}
		
		balance += winnings;
		
		balanceLabel.setText("Balance: $" + balance);

		return winnings;

	}
	
	public static boolean isNumeric(String checkString) { 
		
		try {  
			  
			Double.parseDouble(checkString);  
		    
			return true;
		    
		  } catch(NumberFormatException e){ 
			  
		    return false;  
		    
		  }  
		  
	}

	//feel free to remove the starter code from this method
	@Override
	public void start(Stage primaryStage) {
		
		for (int i = 0; i < 6; i++) {
			
		    ImageView imageView = new ImageView();
		    
		    imageView.setFitWidth(180);
		    
		    imageView.setFitHeight(270);
		    
		    cardPNGs.add(imageView);
		    
		}
		
		//Top HBox------------------------------------------------------
		
		//Title and style definition
		Label baccaratTitle = new Label("Baccarat");
		baccaratTitle.setStyle("-fx-font-size: 48px; -fx-font-weight: bold;");

		//Balance Label
		balanceLabel.setText("Balance: $" + balance);
		balanceLabel.setStyle("-fx-font-size: 48px; -fx-font-weight: bold;");

		//Drop down menu definition and style
		ChoiceBox<String> choiceBox = new ChoiceBox<>();
		choiceBox.getItems().addAll("Fresh Start", "Close");

		Region spacer1 = new Region();
		Region spacer2 = new Region();

		HBox.setHgrow(spacer1, Priority.ALWAYS);
		HBox.setHgrow(spacer2, Priority.ALWAYS);

		//Combine into one HBox
		HBox topBox = new HBox();
		topBox.setAlignment(Pos.CENTER);  // Change this line
		topBox.setSpacing(10);
		topBox.getChildren().addAll(baccaratTitle, spacer1, balanceLabel, spacer2, choiceBox);

		//Center HBox---------------------------------------------------------
		
		// Player's card HBox
        HBox playerCardsRegion = new HBox(5);
        
        for (int i = 0; i < 3; i++) {
        	
            cardPNGs.add(new ImageView());
            
            playerCardsRegion.getChildren().add(cardPNGs.get(i));
            
        }

        // Banker's card HBox
        HBox bankerCardsRegion = new HBox(5);
        
        for (int i = 3; i < 6; i++) {
        	
            cardPNGs.add(new ImageView());
            
            bankerCardsRegion.getChildren().add(cardPNGs.get(i));
            
        }

        // Player's score
        playerScore.setStyle("-fx-font-weight: bold;");

        // Banker's score
        bankerScore.setStyle("-fx-font-weight: bold;");

        // Combine Player Cards and Score
        VBox playerBox = new VBox(10, playerCardsRegion, playerScore);
        
        playerBox.setAlignment(Pos.CENTER_LEFT);

        // Combine Banker Cards and Score
        VBox bankerBox = new VBox(10, bankerCardsRegion, bankerScore);
        
        bankerBox.setAlignment(Pos.CENTER_RIGHT);

        // Combine both VBoxes into one HBox
        HBox centerBox = new HBox(30, playerBox, new Region(), bankerBox);
        
        // Set the background color to #a35a8b and add padding
        centerBox.setStyle("-fx-background-color: #a35a8b; -fx-padding: 5;");

        // Also set the background color for playerBox and bankerBox
        playerBox.setStyle("-fx-background-color: #a35a8b;");
        
        bankerBox.setStyle("-fx-background-color: #a35a8b;");
        
        // Make the center Region grow to push others to the sides
        HBox.setHgrow(centerBox.getChildren().get(1), Priority.ALWAYS);
        
        // Bottom VBox -----------------------------------------------------
        
        TextField betAmount = new TextField();
        
        betAmount.setPromptText("Enter bet amount");
        
        betAmount.setMaxWidth(200);

        Button betPlayerButton = new Button("Bet Player");
        
        Button betBankerButton = new Button("Bet Banker");
        
        Button betTieButton = new Button("Bet Tie");

        HBox buttonsBox = new HBox(10, betPlayerButton, betBankerButton, betTieButton);
        
        buttonsBox.setAlignment(Pos.CENTER);

        // Add outcomeLabel to your VBox
        VBox bettingControls = new VBox(10, betAmount, buttonsBox, outcomeLabel);
        
        bettingControls.setAlignment(Pos.CENTER);
        
        // Create lines as dividers
        Line divider1 = new Line();
        
        divider1.setEndX(450);
        
        divider1.setStrokeWidth(2);
        
        divider1.setStroke(Color.GRAY);

        Line divider2 = new Line();
        
        divider2.setEndX(450);
        
        divider2.setStrokeWidth(2);
        
        divider2.setStroke(Color.GRAY);

        // Combine everything into a VBox with dividers
        VBox root = new VBox(20, topBox, divider1, centerBox, divider2, bettingControls);
        
        root.setAlignment(Pos.CENTER);
        
        root.setPadding(new Insets(20));

        Scene scene = new Scene(root, 1200, 600);
        
        primaryStage.setTitle("Baccarat Game");
        
        primaryStage.setScene(scene);
        
        primaryStage.show();

        
        betPlayerButton.setOnAction(e -> {
        	
            betWho = "Player";
            
            if(!betAmount.getText().isEmpty()) {
            	
            	if(isNumeric(betAmount.getText())) {
            	
            		currentBet = Double.parseDouble(betAmount.getText());
            	
            		if(currentBet <= 100) {
            		
            			PlayGame();
            		
            		}
            		else {
            		
            			outcomeLabel.setText("Bet too high! The max is 100");
            		
            		}
            	
            	}
            	else {
            		
            		outcomeLabel.setText("Not a valid input");
            		
            	}
            	
            }
            
        });

        betBankerButton.setOnAction(e -> {
        	
            betWho = "Banker";
            
            if(!betAmount.getText().isEmpty()) {
            	
            	if(isNumeric(betAmount.getText())) {
                	
            		currentBet = Double.parseDouble(betAmount.getText());
            	
            		if(currentBet <= 100) {
            		
            			PlayGame();
            		
            		}
            		else {
            		
            			outcomeLabel.setText("Bet too high! The max is 100");
            		
            		}
            	
            	}
            	else {
            		
            		outcomeLabel.setText("Not a valid input");
            		
            	}
            }
        });

        betTieButton.setOnAction(e -> {
        	
            betWho = "Tie";
            
            if(!betAmount.getText().isEmpty()) {
            	
            	if(isNumeric(betAmount.getText())) {
                	
            		currentBet = Double.parseDouble(betAmount.getText());
            	
            		if(currentBet <= 49) {
            		
            			PlayGame();
            		
            		}
            		else {
            		
            			outcomeLabel.setText("Bet too high! The max is 49");
            		
            		}
            	
            	}
            	else {
            		
            		outcomeLabel.setText("Not a valid input");
            		
            	}
            	
            }
            
        });
        
        choiceBox.getSelectionModel().selectedItemProperty().addListener((v, oldValue, newValue) -> {
        	
            if ("Fresh Start".equals(newValue)) {
            	
            	// Clear the card images
            	
                for (ImageView imageView : cardPNGs) {
                	
                    imageView.setImage(null);
                    
                    imageView.setVisible(false);
                    
                }

                // Clear the player and banker hands
                
                if(playerHand != null) {
                	
                    playerHand.clear();
                    
                }
                
                if(bankerHand != null) {
                	
                    bankerHand.clear();
                    
                }

                // Reset the scores and total winnings
                playerScore.setText("Player Score: ");
                
                bankerScore.setText("Banker Score: ");
                
                totalWinnings = 0;
                
                outcomeLabel.setText("");
            	
            	theDealer.generateDeck();
            	
                theDealer.shuffleDeck();
                
            } 
            else if ("Close".equals(newValue)) {
            	
                primaryStage.close();
                
            }

            choiceBox.getSelectionModel().clearSelection();
            
        });
        
    }

}
