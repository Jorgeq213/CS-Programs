# Name:Jorge Quintero
# Project 1: CTA Database App
# System: PyCharm on Windows 11
# Course: CS 341, Spring 2024, UIC
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from datetime import datetime
import sqlite3
import sys


##################################################################
#
# print_stats
#
# Given a connection to the CTA database, executes various
# SQL queries to retrieve and output basic stats.
#
def print_stats(dbConn):
    dbCursor = dbConn.cursor()

    print("General Statistics:")

    dbCursor.execute("Select count(*) From stations;")
    row = dbCursor.fetchone();
    print("  # of stations:", f"{row[0]:,}")

    dbCursor.execute("Select count(*) From stops;")
    row = dbCursor.fetchone();
    print("  # of stops:", f"{row[0]:,}")

    dbCursor.execute("Select count(*) from ridership;")
    row = dbCursor.fetchone();
    print("  # of ride entries:", f"{row[0]:,}")

    dbCursor.execute(
        "Select strftime('%Y-%m-%d', min(ride_date)) , strftime('%Y-%m-%d', max(ride_date)) from ridership;")
    row = dbCursor.fetchone();
    print("  date range:", row[0], "-", row[1])

    dbCursor.execute("Select sum(Num_Riders) From Ridership;")
    row = dbCursor.fetchone();
    print("  Total ridership:", f"{row[0]:,}")


# END

##################################################################

def first_Command(dbConn):
    dbCursor = dbConn.cursor()
    print()
    pick_Station = input("Enter partial station name (wildcards _ and %): ")
    #Query for seraching station names
    dbCursor.execute("SELECT station_ID, station_name FROM Stations WHERE station_name LIKE ? ORDER BY station_name ASC",(pick_Station,))
    total_rows = dbCursor.fetchall()
    if len(total_rows) == 0:
        print("**No stations found...")
    else:
        for row in total_rows:
            print(row[0], ":", row[1])

def second_Command(dbConn):
    dbCursor = dbConn.cursor()
    print()
    pick_Station = input("Enter the name of the station you would like to analyze: ")
    #Query to retrieve the station
    dbCursor.execute("SELECT station_name FROM stations WHERE station_name = ?;", (pick_Station,))
    station = dbCursor.fetchone()
    if station is None:
        print("**No data found...")
        return
    print("Percentage of ridership for the ", pick_Station, " station:")
    #Queries to retrieve total amounts for weekdays, saturday, and sunday
    dbCursor.execute("SELECT sum(num_riders) FROM ridership JOIN stations ON (ridership.station_ID=stations.station_ID) WHERE station_name = ?;",(pick_Station,))
    total_row = dbCursor.fetchone()
    total = total_row[0] if total_row is not None else 0
    dbCursor.execute("SELECT sum(num_riders) FROM ridership JOIN stations ON (ridership.station_ID=stations.station_ID) WHERE station_name = ? AND type_of_day = 'W';",(pick_Station,))
    weekTotal_row = dbCursor.fetchone()
    weekTotal = weekTotal_row[0] if weekTotal_row else 0
    dbCursor.execute("SELECT sum(num_riders) FROM ridership JOIN stations ON (ridership.station_ID=stations.station_ID) WHERE station_name = ? AND type_of_day = 'A';",(pick_Station,))
    saturdayTotal_row = dbCursor.fetchone()
    saturdayTotal = saturdayTotal_row[0] if saturdayTotal_row else 0
    dbCursor.execute("SELECT sum(num_riders) FROM ridership JOIN stations ON (ridership.station_ID=stations.station_ID) WHERE station_name = ? AND type_of_day = 'U';", (pick_Station,))
    sundayTotal_row = dbCursor.fetchone()
    sundayTotal = sundayTotal_row[0] if sundayTotal_row else 0
    if total > 0:
        weekPercent = (weekTotal / total) * 100
        saturdayPercent = (saturdayTotal / total) * 100
        sundayPercent = (sundayTotal / total) * 100
        print(" Weekday ridership: ", f"{weekTotal:,}", f"({weekPercent:.2f}%)")
        print(" Saturday ridership: ", f"{saturdayTotal:,}", f"({saturdayPercent:.2f}%)")
        print(" Sunday/holiday ridership: ", f"{sundayTotal:,}", f"({sundayPercent:.2f}%)")
    else:
        print(" No ridership data available.")
    print(" Total ridership: ", f"{total:,}")
    print()


def third_Command(dbConn):
    dbCursor = dbConn.cursor()
    # Retrieves total number of riders for station name
    dbCursor.execute("""SELECT stations.station_name, SUM(ridership.num_riders) as total_ridership FROM stations JOIN ridership ON stations.station_ID = ridership.station_ID WHERE ridership.type_of_day = 'W' GROUP BY stations.station_name ORDER BY total_ridership DESC; """)
    total_row = dbCursor.fetchall()
    weekTotal = sum(row[1] for row in total_row)
    print("Ridership on Weekdays for Each Station")
    for station_name, ridership in total_row:
        percentage = (ridership / weekTotal) * 100
        print(f"{station_name} : {ridership:,} ({percentage:.2f}%)")

def fourth_Command(dbConn):
    dbCursor = dbConn.cursor()
    print()
    # Convert line color to upper case for case-insensitive comparison
    line_color = input("Enter a line color (e.g. Red or Yellow): ").upper()
    # Check if the line color exists before asking for the direction
    dbCursor.execute("SELECT COUNT(*) FROM Lines WHERE UPPER(Color) = ?", (line_color,))
    line_count = dbCursor.fetchone()[0]
    if line_count == 0:
        print("**No such line...")
        return
    # Convert direction to uppercase
    direction_input = input("Enter a direction (N/S/W/E): ").upper()
    # Get stops for the specified color and direction
    dbCursor.execute("SELECT Stops.Stop_Name, Stops.Direction, Stops.ADA FROM Stops INNER JOIN StopDetails ON Stops.Stop_ID = StopDetails.Stop_ID INNER JOIN Lines ON StopDetails.Line_ID = Lines.Line_ID WHERE UPPER(Lines.Color) = ? AND UPPER(Stops.Direction) = ? ORDER BY Stops.Stop_Name ASC",(line_color, direction_input))
    stops = dbCursor.fetchall()
    if not stops:
        print("**That line does not run in the direction chosen...")
        return
    for stop in stops:
        ada_status = "handicap accessible" if stop[2] else "not handicap accessible"
        print(f"{stop[0]} : direction = {stop[1]} ({ada_status})")
    print()

def fifth_Command(dbConn):
    dbCursor = dbConn.cursor()
    # Query for total stops for each color and direction
    dbCursor.execute("SELECT Lines.Color, Stops.Direction, COUNT(*) as StopCount FROM Lines JOIN StopDetails ON Lines.Line_ID = StopDetails.Line_ID JOIN Stops ON StopDetails.Stop_ID = Stops.Stop_ID GROUP BY Lines.Color, Stops.Direction ORDER BY Lines.Color, Stops.Direction")
    stop_data = dbCursor.fetchall()
    # Retrieves total stops for each color
    dbCursor.execute("SELECT COUNT(Stop_Id) FROM Stops")
    total_stops = dbCursor.fetchone()
    print("Number of Stops For Each Color By Direction")
    for color, direction, count in stop_data:
        percentage = (count / total_stops[0]) * 100
        print(f"{color} going {direction} : {count} ({percentage:.2f}%)")
    print()

def sixth_Command(dbConn):
    dbCursor = dbConn.cursor()
    print()
    station_name = input("Enter a station name (wildcards _ and %): ")
    station_name = station_name.replace('*', '%').replace('?', '_')
    # Query for station name retrieval
    dbCursor.execute("SELECT Station_Name FROM Stations WHERE Station_Name LIKE ?", (station_name,))
    matching_stations = dbCursor.fetchall()
    #Station check
    if len(matching_stations) == 0:
        print("**No station found...")
        print()
        return
    elif len(matching_stations) > 1:
        print("**Multiple stations found...")
        print()
        return
    else:
        exact_station_name = matching_stations[0][0]
    dbCursor.execute("SELECT strftime('%Y', Ride_Date) as Year, SUM(Num_Riders) as Total_Ridership FROM Ridership JOIN Stations ON Ridership.Station_ID = Stations.Station_ID WHERE Station_Name = ? GROUP BY Year ORDER BY Year",(exact_station_name,))
    results = dbCursor.fetchall()
    if results:
        print(f"Yearly Ridership at {exact_station_name}")
        years = []
        counts = []
        for year, total in results:
            formatted_total = f"{total:,}"
            print(f"{year} : {formatted_total}")
            years.append(year)
            counts.append(total)
        print()
        plot_data = input("Plot? (y/n) ")
        print()
        if plot_data == 'y':
            plt.figure(figsize=(10, 5))
            plt.plot(years, counts, marker='o')
            plt.title(f"Yearly Ridership at {exact_station_name}")
            plt.xlabel('Year')
            plt.ylabel('Total Ridership')
            plt.grid(True)
            plt.show()

def seventh_Command(dbConn):
    dbCursor = dbConn.cursor()
    print()
    station_name = input("Enter a station name (wildcards _ and %): ")
    # Query to find matching stations
    dbCursor.execute("SELECT Station_Name FROM Stations WHERE Station_Name LIKE ?", (station_name,))
    matching_stations = dbCursor.fetchall()
    if len(matching_stations) == 0:
        print("**No station found...")
        return
    elif len(matching_stations) > 1:
        print("**Multiple stations found...")
        return
    else:
        # Stores similar named stations
        exact_station_name = matching_stations[0][0]
    year = input("Enter a year: ")
    # Query for the total ridership per month for the station and year
    dbCursor.execute("SELECT strftime('%m/%Y', Ride_Date) as Month, SUM(Num_Riders) as Total_Ridership FROM Ridership JOIN Stations ON Ridership.Station_ID = Stations.Station_ID WHERE Station_Name = ? AND strftime('%Y', Ride_Date) = ? GROUP BY Month ORDER BY Ride_Date",(exact_station_name, year,))
    results = dbCursor.fetchall()
    print(f"Monthly Ridership at {exact_station_name} for {year}")
    months = []
    riderships = []
    for month, total_ridership in results:
        month_date = datetime.strptime(month, '%m/%Y')
        print(f"{month_date.strftime('%m/%Y')} : {total_ridership:,}")
        months.append(month_date)
        riderships.append(total_ridership)
        # Ask the user if they want to plot the data
    plot_data = input("Plot? (y/n) ")
    print()
    if plot_data.lower() == 'y':
        plt.figure(figsize=(10, 5))
        plt.plot(months, riderships, marker='o', linestyle='-')
        plt.title(f"Monthly Ridership at {exact_station_name} for {year}")
        plt.xlabel('Month')
        plt.ylabel('Total Ridership')
        plt.gca().xaxis.set_major_locator(mdates.MonthLocator())
        plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%B %Y'))
        plt.xticks(rotation=45)
        plt.tight_layout()
        plt.grid(True)
        plt.show()

def eighth_Command(dbConn):
    dbCursor = dbConn.cursor()
    print()
    year = input("Year to compare against? ").strip()
    print()
    station1 = input("Enter station 1 (wildcards _ and %): ").strip()
    # Check for station 1
    dbCursor.execute("SELECT Station_Name, Station_ID FROM Stations WHERE Station_Name LIKE ?", (station1,))
    stations = dbCursor.fetchall()
    if len(stations) == 0:
        print("**No station found...")
        return
    elif len(stations) > 1:
        print("**Multiple stations found...")
        return
    station1 = stations[0][0]  # Assuming the station name is the first column
    station1ID = stations[0][1]
    print()
    station2 = input("Enter station 2 (wildcards _ and %): ").strip()
    # Check for station 2
    dbCursor.execute("SELECT Station_Name, Station_ID FROM Stations WHERE Station_Name LIKE ?", (station2,))
    stations = dbCursor.fetchall()
    if len(stations) == 0:
        print("**No station found...")
        return
    elif len(stations) > 1:
        print("**Multiple stations found...")
        return
    station2 = stations[0][0]  # Stores station name
    station2ID = stations[0][1] # stores station id
    # Retrieve and print ridership data for station 1
    dbCursor.execute("SELECT strftime('%Y-%m-%d', Ride_Date) as RideDate, SUM(Num_Riders) as Total_Ridership FROM Ridership WHERE Station_ID IN (SELECT Station_ID FROM Stations WHERE Station_Name = ?) AND strftime('%Y', Ride_Date) = ? GROUP BY RideDate ORDER BY RideDate",(station1, year,))
    ridership1 = dbCursor.fetchall()
    # Retrieve and print ridership data for station 2
    dbCursor.execute("SELECT strftime('%Y-%m-%d', Ride_Date) as RideDate, SUM(Num_Riders) as Total_Ridership FROM Ridership WHERE Station_ID IN (SELECT Station_ID FROM Stations WHERE Station_Name = ?) AND strftime('%Y', Ride_Date) = ? GROUP BY RideDate ORDER BY RideDate",(station2, year,))
    ridership2 = dbCursor.fetchall()
    # Print ridership data for station 1
    print(f"Station 1: {station1ID} {station1} ")
    for row in ridership1[:5] + ridership1[-5:]:
        print(f"{row[0]}  {row[1]}")
    # Print ridership data for station 2
    print(f"Station 2: {station2ID} {station2} ")
    for row in ridership2[:5] + ridership2[-5:]:
        print(f"{row[0]}  {row[1]}")
    # Ask the user if they want to plot the data
    plot_data = input("Plot? (y/n) ").strip().lower()
    print()
    if plot_data == 'y':
        dates = [datetime.strptime(row[0], '%Y-%m-%d') for row in ridership1]
        start_date = dates[0]
        day_numbers = [(date - start_date).days for date in dates]
        riderships1 = [row[1] for row in ridership1]
        riderships2 = [row[1] for row in ridership2]
        plt.figure(figsize=(7, 5))
        plt.plot(day_numbers, riderships1, label=station1)
        plt.plot(day_numbers, riderships2, label=station2)
        plt.title(f"Ridership Each Day of {year}")
        plt.xlabel("Day")
        plt.xticks(range(0, max(day_numbers) + 1, 50))
        plt.ylabel("Number of Riders")
        plt.legend()
        plt.tight_layout()
        plt.show()

def ninth_Command(dbConn):
    dbCursor = dbConn.cursor()
    print()
    user_lat = float(input("Enter a latitude: "))
    if not (40 <= user_lat <= 43):
        print("**Latitude entered is out of bounds...")
        return
    user_long = float(input("Enter a longitude: "))
    if not (-88 <= user_long <= -87):
        print("**Longitude entered is out of bounds...")
        return
    lat_degree = 1 / 69  # represents how many degrees are in one mile
    long_degree = 1 / 51  # represents how many degrees are in one mile
    lat_min = round(user_lat - lat_degree, 3)
    lat_max = round(user_lat + lat_degree, 3)
    long_min = round(user_long - long_degree, 3)
    long_max = round(user_long + long_degree, 3)
    dbCursor.execute("Select DISTINCT station_Name, Latitude, Longitude from Stations JOIN Stops ON (Stations.station_ID=Stops.station_ID) where latitude between ? and ? and longitude between ? AND ? order by station_Name",(lat_min, lat_max, long_min, long_max,))
    stations = dbCursor.fetchall()
    if len(stations) == 0:  # checks if nothing was returned, if so print respective error code
        print("**No stations found...")
        return  # return to main
    print()
    print("List of Stations Within a Mile")
    for station in stations:  # Output the stations
        print(station[0], ":", f"{station[1], station[2]}")
    print()
    plotGraph = input("Plot? (y/n) ")
    print()
    if plotGraph.lower() == 'y':
        image = plt.imread("chicago.png")
        xydims = [-87.9277, -87.5569, 41.7012, 42.0868]  # The geographical extent the image covers
        # Show the image without scaling by using the aspect ratio 'equal'
        plt.imshow(image, extent=xydims, aspect='equal')
        plt.title("Map of Chicago with Stations")
        # Extract station names, longitudes, and latitudes from the fetched data
        station_names = [station[0] for station in stations]
        longitudes = [station[2] for station in stations]
        latitudes = [station[1] for station in stations]
        # Plot and annotate each station on the map
        for name, lon, lat in zip(station_names, longitudes, latitudes):
            plt.plot(lon, lat, 'o')  # Mark the station
            plt.annotate(name, (lon, lat))
        plt.xlim([xydims[0], xydims[1]])
        plt.ylim([xydims[2], xydims[3]])
        plt.show()
#
# main
#
print('** Welcome to CTA L analysis app **')
print()

dbConn = sqlite3.connect('CTA2_L_daily_ridership.db')

print_stats(dbConn)

while True:
    user_input = input("Please enter a command (1-9, x to exit): ")
    # Quits the program
    if user_input == 'x':
        sys.exit(0)

    try:
        # Convert the input to an integer
        number = int(user_input)
        # Picks the number Inputted
        # Functions are exceuted
        if 1 <= number <= 9:
            if 1 <= number <= 9:
                if number == 1:
                    first_Command(dbConn)
                elif number == 2:
                    second_Command(dbConn)
                elif number == 3:
                    third_Command(dbConn)
                elif number == 4:
                    fourth_Command(dbConn)
                elif number == 5:
                    fifth_Command(dbConn)
                elif number == 6:
                    sixth_Command(dbConn)
                elif number == 7:
                    seventh_Command(dbConn)
                elif number == 8:
                    eighth_Command(dbConn)
                elif number == 9:
                    ninth_Command(dbConn)
        else:
            print("**Error, unknown command, try again...")
            print()
    except ValueError:
        # Handle the case where input is not an integer or x
        print("**Error, unknown command, try again...")
        print()
#
# done
#