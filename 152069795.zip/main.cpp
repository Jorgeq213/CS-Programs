/**************************
 * Jorge Quintero
 * Program 6: Graph
 * Windows 10 DEV c++
 * Prof Kidane
 * CS 141
 * ************************/

#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

//************************** Node *************************

class Node{
public:
    Node() {
        data = 0;
        pNext = NULL;
    }
    Node(int data) {
        this->data = data;
        this->pNext = NULL;
    }
    int data;
    Node *pNext;
};

//************************** Graph ****************************
class Graph {
public:
    //add the node with neighborId as the neighbor of nodeId
    void addNeighbor(int nodeId, int neighborId){
      Node* pTemp = new Node;
      Node* pCurr = vertices.at(nodeId);
      pTemp->data = neighborId;
      pTemp->pNext = NULL;

      if(vertices.at(nodeId)==NULL){
          vertices.at(nodeId)=pTemp;
          numEdge++;
      }
      else if(vertices.at(nodeId)->data > pTemp->data){
          pTemp->pNext = vertices.at(nodeId);
          vertices.at(nodeId) = pTemp;
          numEdge++;
      }
      else if(vertices.at(nodeId)->data < pTemp->data){
          while((pCurr->data < pTemp->data) && (pCurr-> pNext !=NULL) && (pCurr->pNext->data < pTemp->data)){
              pCurr = pCurr->pNext;
          }
      if((pCurr->pNext != NULL) && (pCurr->pNext->data > pTemp->data)){
          pTemp->pNext = pCurr->pNext;
          pCurr->pNext = pTemp;
          numEdge++;
      }
      else{
          pCurr->pNext = pTemp;
          numEdge++;
      }
      }
      if(!searchNeighbors(neighborId,nodeId)){
          addNeighbor(neighborId,nodeId);
      }

    };

   
    //reads the edge list from file and creates the adjacency list data structure
    void loadGraph(string edgeListFileName){
        ifstream stream1;
        int nodeId;
        int neighborId;
        stream1.open(edgeListFileName, ios::in);
        if(stream1.is_open()) {
            while (!stream1.eof()) {
                stream1 >> nodeId;
                stream1 >> neighborId;
                while(vertices.size() <= nodeId || vertices.size() <= neighborId){
                    vertices.push_back(NULL);
                }
                if(!searchNeighbors(nodeId, neighborId)){
                    addNeighbor(nodeId, neighborId);
                }
            }
            stream1.close();
        }
        };

    //writes the adjacency list into the file
    void dumpGraph(string adjListFileName){
        fstream adjList;
        Node* pFile;
        adjList.open(adjListFileName, ios:: out);
        if(adjList.is_open()){
            for(int i = 0; i < vertices.size(); i++){
                if(vertices.at(i) != NULL){
                    adjList << i << ": ";
                    pFile = vertices.at(i);
                    while((pFile != NULL) && (pFile->pNext != NULL)){
                        adjList << pFile->data << " ";
                        pFile = pFile->pNext;
                    }
                    if(pFile->pNext == NULL){
                        adjList << pFile->data;
                    }
                    adjList << endl;
                }
            }
        }



    };

    //Prints number of nodes, number of edges, and maximum degree on terminal
    void printGraphInfo(){
        cout << "Number of nodes: " << getNumVertices() << endl;
        cout << "Number of edges: " << (numEdge/2)<< endl;
        cout << "Maximum degree: "  << getHighDeg() << endl;
    };

    //returns the number of neighbor (degree) of a node
    int getNumNeighbors(int nodeId){
       Node* pLast = vertices.at(nodeId);
       int count = 0;
       while(pLast != NULL){
           pLast = pLast->pNext;
           count++;
       }
       return count;
    };
    

    //returns the number of nodes in the graph
    int getNumVertices(){
        int numVer=0;
        for(int i = 0; i < vertices.size(); i++){
            if(vertices.at(i)!= NULL){
                numVer++;
            }
        }
        return numVer;
    };
  
    bool searchNeighbors(int nodeId, int neighborId){
        Node* pCurr = vertices.at(nodeId);
        while(pCurr != NULL){
            if(pCurr->data == neighborId){
                return true;
            }
            pCurr = pCurr->pNext;
        }
        return false;
    }
    int getHighDeg(){
        int maxDeg = 0;
        int nodeDeg = 0;
        for(int i = 0; i < vertices.size(); i++){
            nodeDeg = getNumNeighbors(i);
            if(nodeDeg > maxDeg) {
                maxDeg = nodeDeg;
            }
        }
        return maxDeg;
    }

private:
    vector<Node*> vertices;
    int numEdge = 0;
};


void run(string edgeListFileName, string adjListFileName) {
    Graph print;
    print.loadGraph(edgeListFileName);
    print.printGraphInfo();
    print.dumpGraph(adjListFileName);

}

//*****************************************************************************


// The main will be removed for testing, do not add any code in the main function
int main() {
    //Change the filenames according to your local path.
    string edgeListFileName("karate.txt");
    string adjListFileName("karate_adj.txt");
    run(edgeListFileName, adjListFileName);
    return 0;
}