/// @file tests.cpp
/// @date March 17, 2023
/*Author: Jorge Quintero
  Project 5 Deqeue
  Prof Dr. Khoelher
  Tests cases Provided by: Abdul Gaffir Zambi azamb2@uic.edu, 
  Went to OH Hours
*/
/// 
/// TODO

/// Provided testing file to implement framework based tests in. The examples
/// below demonstrates a basic empty test in each framework with a single
/// assertion. The version uses the supplied catch.hpp file in starter code.
///
/// Assignment details and provided code are created and
/// owned by Adam T Koehler, PhD - Copyright 2023.
/// University of Illinois Chicago - CS 251 Spring 2023

// TODO:
// Choose which framework to keep and delete the other.
//

/*
// Catch 1.0 Framework Testing
#define CATCH_CONFIG_MAIN

#include "catch.hpp"
#include "priorityqueue.h"

using namespace std;

TEST_CASE("(0) no tests") 
{
    REQUIRE(true);
}
*/


/*
// Google Test Framework Testing
#include <gtest/gtest.h>
#include "priorityqueue.h"

TEST(classname, one) {
    EXPECT_EQ(true);
}
*/
#include <string>
#include <vector>

using namespace std;

#include "priorityqueue.h"

int main() {
TEST_CASE("copy constructor and assignment operator") {
    priorityqueue<int> pq1;
    pq1.enqueue(1, 1);
    pq1.enqueue(2, 2);
    pq1.enqueue(3, 3);
    priorityqueue<int> pq2 = pq1;
    REQUIRE(pq1.dequeue() == 3);
    REQUIRE(pq1.dequeue() == 2);
    REQUIRE(pq1.dequeue() == 1);
    REQUIRE(pq1.size() == 0);
    REQUIRE(pq2.dequeue() == 3);
    REQUIRE(pq2.dequeue() == 2);
    REQUIRE(pq2.dequeue() == 1);
    REQUIRE(pq2.size() == 0);
    pq2.enqueue(4, 4);
    pq2.enqueue(5, 3);
    pq2.enqueue(6, 4);
    pq1 = pq2;
    REQUIRE(pq1.dequeue() == 6);
    REQUIRE(pq1.dequeue() == 4);
    REQUIRE(pq1.dequeue() == 5);
    REQUIRE(pq1.size() == 0);
    REQUIRE(pq2.dequeue() == 6);
    REQUIRE(pq2.dequeue() == 4);
    REQUIRE(pq2.dequeue() == 5);
    REQUIRE(pq2.size() == 0);
    pq1.clear();
    pq2.clear();
}
TEST_CASE("enqueue and dequeue work correctly") {
    PriorityQueue<int> pq;
    pq.enqueue(5, 1);
    pq.enqueue(10, 2);
    pq.enqueue(15, 1);
    pq.enqueue(20, 3);
    pq.enqueue(25, 2);

    REQUIRE(pq.Size() == 5);

    int val = pq.dequeue();
    REQUIRE(val == 5);
    REQUIRE(pq.Size() == 4);

    val = pq.dequeue();
    REQUIRE(val == 15);
    REQUIRE(pq.Size() == 3);

    val = pq.dequeue();
    REQUIRE(val == 10);
    REQUIRE(pq.Size() == 2);

    val = pq.dequeue();
    REQUIRE(val == 25);
    REQUIRE(pq.Size() == 1);

    val = pq.dequeue();
    REQUIRE(val == 20);
    REQUIRE(pq.Size() == 0);

    val = pq.dequeue();
    REQUIRE(val == 0);
    REQUIRE(pq.Size() == 0);
}

TEST_CASE("duplicate priorities work correctly") {
    PriorityQueue<int> pq;
    pq.enqueue(5, 1);
    pq.enqueue(10, 2);
    pq.enqueue(15, 1);
    pq.enqueue(20, 3);
    pq.enqueue(25, 2);
    pq.enqueue(30, 3);
    pq.enqueue(35, 2);
    pq.enqueue(40, 1);

    REQUIRE(pq.Size() == 8);

    int val = pq.dequeue();
    REQUIRE(val == 5);
    REQUIRE(pq.Size() == 7);

    val = pq.dequeue();
    REQUIRE(val == 15);
    REQUIRE(pq.Size() == 6);

    val = pq.dequeue();
    REQUIRE(val == 40);
    REQUIRE(pq.Size() == 5);

    val = pq.dequeue();
    REQUIRE(val == 10);
    REQUIRE(pq.Size() == 4);

    val = pq.dequeue();
    REQUIRE(val == 25);
    REQUIRE(pq.Size() == 3);

    val = pq.dequeue();
    REQUIRE(val == 35);
    REQUIRE(pq.Size() == 2);

    val = pq.dequeue();
    REQUIRE(val == 20);
    REQUIRE(pq.Size() == 1);

    val = pq.dequeue();
    REQUIRE(val == 30);
    REQUIRE(pq.Size() == 0);

    val = pq.dequeue();
    REQUIRE(val == 0);
    REQUIRE(pq.Size() == 0);


} 
    TEST_CASE("priorityqueue size")
{
    priorityqueue<string> newNode;
    newNode.enqueue("Abena", 1);
    newNode.enqueue("joe", 5);
    newNode.enqueue("yaa", 7);
    newNode.enqueue("jay", 9);
    newNode.enqueue("cyndy", 4);
    newNode.enqueue("mansa", 4);
    newNode.enqueue("dee", 4);
    newNode.enqueue("nimo", 4);
    newNode.enqueue("yaw", 6);
    REQUIRE(newNode.Size() == 9);
    
    newNode.dequeue();
    
    REQUIRE(newNode.Size() == 8);
    
    newNode.clear();
    REQUIRE(newNode.Size() == 0);
    
    
}
TEST_CASE("priorityqueue peek() and enqueue")
{
    priorityqueue<string> newNode;
    newNode.enqueue("Abena", 1);
    newNode.enqueue("joe", 5);
    newNode.enqueue("yaa", 7);
    string key;
    key = newNode.peek();
    REQUIRE(key == "Abena");
    
}

}
