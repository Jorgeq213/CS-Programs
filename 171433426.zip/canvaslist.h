/*
Program 4: Shape List
Author: Jorge Quintero
IDE: Windows 11 VSCode
Prof: Koehler
//Went to office hours

*/
#pragma once

#include "shape.h"
#include <iostream>

using namespace std;

class ShapeNode
{
    public:
        Shape *value;
        ShapeNode *next;
};

class CanvasList
{
    private:
        int listSize;
        ShapeNode *listFront;

    public:
        CanvasList();
        CanvasList(const CanvasList &);
        CanvasList operator=(const CanvasList &);
        
        virtual ~CanvasList();
        void clear();
        
        void insertAfter(int, Shape *);
        void push_front(Shape *);
        void push_back(Shape *);
        
        void removeAt(int);
        Shape* pop_front();
        Shape* pop_back();

        ShapeNode* front() const;
        bool isempty() const;
        int size() const;

        int find(int x, int y) const;
        Shape* shapeAt(int) const;
        
        void draw() const;
        void printAddresses() const;
};
CanvasList::CanvasList(){
    this->listSize = 0;
    this->listFront = nullptr;
}
CanvasList::CanvasList(const CanvasList &copy){
    ShapeNode* pHead = copy.listFront;
    this->listFront = nullptr;
    this->listSize = 0;
    while(pHead != nullptr){
        this->push_back(pHead->value->copy());
        pHead = pHead->next;
    }
}
CanvasList CanvasList::operator=(const CanvasList &copy) {
    if (this == &copy) {
        return *this;
    }
    clear();
    ShapeNode* pHead = copy.listFront;
    this->listFront = nullptr;
    this->listSize = 0;
    while (pHead != nullptr) {
        this->push_back(pHead->value->copy());
        pHead = pHead->next;
    }
    return *this;
}
CanvasList::~CanvasList(){
 clear();
}
void CanvasList::clear(){
    while(listFront != nullptr){
        ShapeNode* temp = listFront;
        listFront = listFront->next;
        delete temp->value;
        delete temp;
    }
    listSize = 0;
}
void CanvasList::insertAfter(int num1, Shape* shapeInput)
{
    if (num1 < 0 || num1 >= listSize){
        return;
    }
    if (listSize == 0){
        listFront->value = shapeInput;
        listSize++;
        return;
    }
    ShapeNode* pHead = listFront;
    for (int i = 0; i < num1; i++){
        pHead = pHead->next;
    }
    ShapeNode* newptr = new ShapeNode;
    newptr->value = shapeInput;
    newptr->next = pHead->next;
    pHead->next = newptr;
    listSize++;
}
void CanvasList::push_front(Shape* shapeInput){
    ShapeNode* frontShape = new ShapeNode;
    frontShape-> value = shapeInput;
    frontShape->next = listFront;
    listFront = frontShape;
    listSize++;
}
void CanvasList::push_back(Shape* shapeInput){
    ShapeNode* newptr = new ShapeNode;
    newptr->value = shapeInput;
    newptr->next = nullptr;
    if(listFront == nullptr){
        listFront = newptr;
    }
    else{
        ShapeNode* pHead = listFront;
        while(pHead->next != nullptr){
            pHead = pHead->next;
        }
        pHead->next = newptr;
    }
    listSize++;
}
void CanvasList::removeAt(int num1){
    if(num1 < 0 || num1 >= listSize){
        return;
    }
    ShapeNode* temp = listFront;
    ShapeNode* pTail = nullptr;
    int num = 0;
    while(temp != nullptr){
        if(num == num1){
            if(pTail == nullptr){
            listFront = temp->next;
            
        }
        else{
            pTail->next = temp->next;
        }
        delete temp->value;
        delete temp;
        listSize--;
        return;
    }
    pTail = temp;
    temp = temp->next;
    num++;
    }
}
Shape* CanvasList::pop_front(){
    if(listFront == nullptr){
        return nullptr;
    }
    ShapeNode* nextList = listFront;
    Shape* temp = listFront->value;
    listFront = listFront->next;
    delete nextList;
    listSize--;
    return temp;
}
Shape* CanvasList::pop_back(){
    if(listFront == nullptr){
        return nullptr;
    }
    ShapeNode* nextList = listFront;
    ShapeNode* pTail = nullptr;
    while(nextList->next != nullptr){
        pTail = nextList;
        nextList = nextList->next;
    }
    Shape* temp = nextList->value;
    delete nextList;
    listSize--;
    if(pTail == nullptr){
        listFront = nullptr;
    }
    else{
        pTail->next = nullptr;
    }
    return temp;
}
ShapeNode* CanvasList::front() const{
    return listFront;
}
int CanvasList::find(int x, int y) const{
    int num = 0;
    ShapeNode* pHead = listFront;
    while(pHead!= nullptr){
        if(pHead->value->getX() == x && pHead->value->getY() ==y){
            return num;
        }
        pHead = pHead->next;
        num++;
    }
    return -1;
}
Shape* CanvasList::shapeAt(int num1) const{
    if(num1 >= listSize || num1 < 0){
        return nullptr;
    }
    ShapeNode* pHead = listFront;
    for(int i = 0; i < num1; i++){
        pHead = pHead->next;
    }
    return pHead->value;
}
void CanvasList::draw() const{
    if(listFront == nullptr){
        return;
    }
    ShapeNode* temp = listFront;
    while(temp->next != nullptr){
        temp->value->printShape();
        temp = temp->next;
    }
}
void CanvasList::printAddresses() const{
    if(listFront == nullptr){
        return; 
    }
    ShapeNode* temp = listFront;
    while(temp->next != nullptr){
        cout << temp << endl;
        temp = temp->next;
    }
}
bool CanvasList:: isempty() const{
    if(listSize == 0){
        return true;
    }
    else{
        return false;
    }
}
int CanvasList::size() const{
    return this->listSize;
}