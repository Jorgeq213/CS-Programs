/*
Program 4: Shape List
Author: Jorge Quintero
IDE: Windows 11 VSCode
Prof: Koehler
//Went to office hours

*/
#pragma once

using namespace std;

class Shape
{
    protected:
        int x;
        int y;

    public: 
        Shape();
        Shape(int x, int y);

        virtual ~Shape();
        virtual Shape* copy();

        int getX() const;
        int getY() const;
        void setX(int);
        void setY(int);
        
        virtual void printShape() const;
};
Shape::Shape(){
    this->x=0;
    this->y=0;
}
Shape::Shape(int x, int y){
    this->setX(x);
    this->setY(y);
}
Shape::~Shape(){

}
Shape* Shape::copy(){
    return new Shape(x,y);
}
int Shape::getX() const{
    return this->x;
}
int Shape::getY() const{
    return this->y;
}
void Shape::setX(int newX){
    this->x = newX;
}
void Shape::setY(int newY){
    this->y = newY;
}
void Shape::printShape() const{
    cout << "It's a shape at x: "<<this->getX() << ", y: " << this->getY() << endl;
}
class Circle : public Shape 
{
    private:
        int radius;

    public: 
        Circle();
        Circle(int r);
        Circle(int x, int y, int r);

        virtual ~Circle();
        virtual Circle* copy();
        
        int getRadius() const;
        void setRadius(int);
        
        virtual void printShape() const;
};

Circle::Circle():Shape(){
    this->radius = 0;
}
Circle::Circle(int r):Shape(){
    this->setRadius(r);
}
Circle::Circle(int x, int y, int r):Shape(x,y){
    this->setRadius(r);
}
Circle::~Circle(){

}
Circle* Circle::copy(){
    return new Circle(x,y,radius);
}
int Circle::getRadius() const{
    return this->radius;
}
void Circle::setRadius(int newRadius){
    this->radius = newRadius;
}
void Circle::printShape()const{
    cout << "It's a circle at x: " << this->x << ", y: " << this->y << ", radius: " << this->getRadius() << endl;
}

class Rectangle : public Shape 
{
    private:
        int width;
        int height;

    public: 
        Rectangle();
        Rectangle(int w, int h);
        Rectangle(int x, int y, int w, int h);
        
        virtual ~Rectangle();
        virtual Rectangle* copy();
        
        int getWidth() const;
        int getHeight() const;
        void setWidth(int);
        void setHeight(int);
        
        virtual void printShape() const;
};
Rectangle::Rectangle():Shape(){
    this->width = 0;
    this->height = 0;
}
Rectangle::Rectangle(int w, int h):Shape(){
    this->setWidth(w);
    this->setHeight(h);
}
Rectangle::Rectangle(int x, int y, int w, int h):Shape(x,y){
    this->setWidth(w);
    this->setHeight(h);
}
Rectangle::~Rectangle(){

}
Rectangle* Rectangle::copy(){
    return new Rectangle(x,y,width,height);
}
int Rectangle::getWidth() const{
    return this->width;
}
int Rectangle::getHeight() const{
    return this->height;
}
void Rectangle::setWidth(int newWidth){
    this->width = newWidth;
}
void Rectangle::setHeight(int newHeight){
    this->height = newHeight;
}
void Rectangle::printShape() const{
    cout << "It's a rectangle at x: " << this->x << ", y: " << this->y << " with width: " << this->width << " and height: " << this->height << endl;
}

class RightTriangle : public Shape 
{
    private:
        int base;
        int height;

    public: 
        RightTriangle();
        RightTriangle(int b, int h);
        RightTriangle(int x, int y, int b, int h);
        
        virtual ~RightTriangle();
        virtual RightTriangle* copy();
        
        int getBase() const;
        int getHeight() const;
        void setBase(int);
        void setHeight(int);

        virtual void printShape() const;
};
RightTriangle::RightTriangle():Shape(){
    this->base = 0;
    this->height = 0;
}
RightTriangle::RightTriangle(int b, int h):Shape(){
    this->setBase(b);
    this->setHeight(h);
}
RightTriangle::RightTriangle(int x, int y, int b, int h):Shape(x,y){
    this->setBase(b);
    this->setHeight(h);
}
RightTriangle::~RightTriangle(){

}
RightTriangle* RightTriangle::copy(){
    return new RightTriangle(x,y,base,height);
}
int RightTriangle::getBase() const{
    return this->base;
}
int RightTriangle::getHeight() const{
    return this->height;
}
void RightTriangle::setBase(int newBase){
    this->base = newBase;
}
void RightTriangle::setHeight(int newHeight){
    this->height = newHeight;
}
void RightTriangle::printShape() const{
 cout << "It's a right triangle at x: " << this->x << ", y: " << this->y << " with base: " << this->base << " and height: " << this->height << endl;
}