/// @filename tests.cpp
/// @date March 7, 2023

/// Provided testing file to implement
/// framework based tests in. The example
/// below uses the Catch testing framework
/// version that uses a single .hpp file.

// This tells Catch to provide a main()
/*
Program 4: Shape List
Author: Jorge Quintero
IDE: Windows 11 VSCode
Prof: Koehler
//Went to office hours

*/
#define CATCH_CONFIG_MAIN

#include "catch.hpp"
#include "shape.h"
#include "canvaslist.h"

using namespace std;

TEST_CASE("Testing Shape class") 
{
  Shape shape(5,10);
  REQUIRE(shape.getX() == 5);
  REQUIRE(shape.getY() == 10);
}
TEST_CASE("Testing Circle class") {
    Circle circle(4, 8, 16);
    REQUIRE(circle.getRadius() == 16);
    REQUIRE(circle.getX() == 4);
    REQUIRE(circle.getY() == 8);
}
TEST_CASE("Testing Rectangle class") {
    Rectangle rectangle(2, 4, 6, 8);
    REQUIRE(rectangle.getWidth() == 6);
    REQUIRE(rectangle.getHeight() == 8);
    REQUIRE(rectangle.getX() == 2);
    REQUIRE(rectangle.getY() == 4);
}
TEST_CASE("Testing Triangle class") {
    RightTriangle triangle(1, 2, 3, 4, 5, 6);
    REQUIRE(triangle.getX1() == 1);
    REQUIRE(triangle.getY1() == 2);
    REQUIRE(triangle.getX2() == 3);
    REQUIRE(triangle.getY2() == 4);
    REQUIRE(triangle.getX3() == 5);
    REQUIRE(triangle.getY3() == 6);
}
TEST_CASE("Testing Canvaslist push_front and size") {
  CanvasList canvas;
  REQUIRE(canvas.size() == 0);
  canvas.push_front(new Circle(1, 1, 1));
  REQUIRE(canvas.size() == 1);
  canvas.push_front(new Rectangle(2, 2, 2, 2));
  REQUIRE(canvas.size() == 2);
}
TEST_CASE("Testing Canvaslist pop_back"){
  CanvasList canvas;
  Shape* popShape = canvas.pop_back();
  REQUIRE(popShape != nullptr);
  REQUIRE(canvas.size() == 2);
  REQUIRE(canvas.front()->value->getX() == 2);
  REQUIRE(canvas.front()->value->getY() == 1);
  popShape = canvas.pop_back();
  REQUIRE(popShape != nullptr);
  REQUIRE(canvas.size() == 0);
  REQUIRE(canvas.front() == nullptr);
}
TEST_CASE("Testing Canvaslist clear and size"){
CanvasList canvas;
canvas.push_front(new Circle(1, 1, 2));
canvas.push_front(new Rectangle(2, 2, 3, 4));
REQUIRE(canvas.size() == 2);
canvas.clear();
REQUIRE(canvas.size() == 0);
REQUIRE(canvas.front() == nullptr);
}
TEST_CASE("Testing Canvaslist insertAfter"){
CanvasList canvas;
canvas.push_front(new Circle(1, 1, 2));
canvas.push_front(new Rectangle(2, 2, 3, 4));
canvas.insertAfter(0, new Circle(3, 3, 1));
REQUIRE(canvas.size() == 3);
REQUIRE(canvas.front()->value->getX() == 2);
REQUIRE(canvas.front()->next->value->getX() == 3);
REQUIRE(canvas.front()->next->next->value->getX() == 1);
}