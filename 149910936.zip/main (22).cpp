/****************************
 * Program 5: Yahtzee
  Jorge Quintero
 *Dev C++ Windows 10
 CS 141 Prof Kidane
 * Starter code provided by: Dr. Sara Riazi
 * ***************************/


#include <string>
#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <iomanip>

using namespace std;



//#################################################################################################





class Dice{
private:
    int value;
    bool keep;

public:

    void isKeep(){
        this->keep = true;
    }
    void noKeep(){
        this->keep = false;
    }
    bool keepDice(){
        return this->keep;
    }
    //Randomly assigns a value between from 1 to 6 to the dice.
    void roll(){
        value = rand()%6+1;

    }
    int reveal() {return value;}

    //The autograder will set the values directly instead of calling roll() to avoid randomness!
    void setValue(int value) {this->value = value;}

};


//#################################################################################################

const int HAND_SIZE = 5;

class Hand {
public:

    //Display the value of the five dice
    void show(){
        cout << "Hand: ";
        for(int i=0; i < HAND_SIZE;i++){
            cout << hand[i].reveal() << " ";
        }

    }
    void play(){
        for(int i = 0; i < HAND_SIZE; i++){
            char currChar = char(i+1)+'0';
            if(stringSelection.find(currChar)==-1){
                hand[i].roll();
            }
        }
    }
    Dice* getDice(int diceNum){
        return &hand[diceNum];
    }

    //selection is the string of dice numbers that the player wants to keep.
    //For example, "125" means that player wants to keep the first, second, and fifth dice, and roll the rest.
    void setSelection(string selection){
        stringSelection = selection;
    }

    Hand(){
        for(int i = 0; i < HAND_SIZE; i++){
            hand[i].noKeep();
        }


    }

private:
    Dice hand[HAND_SIZE];
    string stringSelection;
};



//######################################################################


//List of rows in the board
const int ONES = 0;
const int TWOS = 1;
const int THREES = 2;
const int FOURS = 3;
const int FIVES = 4;
const int SIXES = 5;
const int THREE_OF_KIND = 6;
const int FOUR_OF_KIND = 7;
const int FULL_HOUSE = 8;
const int SMALL_STRAIGHT = 9;
const int LARGE_STRAIGHT = 10;
const int CHANCE = 11;
const int YAHTZEE = 12;

const int BOARD_SIZE=13;

class Game {


public:
    bool totalBool[BOARD_SIZE] ={false,false,false,false,false,false,false,false,false,false,false,false,false};
    int total[BOARD_SIZE];
    //calcScore returns a score of a hand (5 dice) for given row in the board.
    //Note the rows are indexed from zero.
    //For example if the hand is 2 1 1 5 1 then calcScore(hand, ONES) returns 3 and  calcScore(hand, TWOS) returns 2.
    int calcScore(Hand* hand, int row){
        int i;
        int j;
        bool allEqual = true;
        int count = 0;
        if(row == ONES){ // loops to look for ones in my die and increment
            for(i=0; i < HAND_SIZE;i++){
                if(hand->getDice(i)->reveal()==1){
                    count++;
                }
            }
            totalBool[ONES]=true;
            return count;
        }
        else if(row == TWOS){ // loops to look for two in my die and increments it by two
            for(i=0; i < HAND_SIZE;i++){
                if(hand->getDice(i)->reveal()==2){
                    count+=2;
                }
            }
            totalBool[TWOS]=true;
            return count;
        }
        else if(row == THREES){ // loops to look for threes in my die and increments it by three
            for(i=0; i < HAND_SIZE;i++){
                if(hand->getDice(i)->reveal()==3){
                    count+=3;
                }
            }
            totalBool[THREES]=true;
            return count;
        }
        else if(row == FOURS){ // loops to look for fours in my die and increments it by four
            for(i=0; i < HAND_SIZE;i++){
                if(hand->getDice(i)->reveal()==4){
                    count+=4;
                }
            }

            totalBool[FOURS]=true;
            return count;
        }
        else if(row == FIVES){ // loops to look for five in my die and increments it by five
            for(i=0; i < HAND_SIZE;i++){
                if(hand->getDice(i)->reveal()==5){
                    count+=5;
                }
            }

            totalBool[FIVES]=true;
            return count;
        }
        else if(row == SIXES){ // loops to look for sixes in my die and increments it by six
            for(i=0; i < HAND_SIZE;i++){
                if(hand->getDice(i)->reveal()==6){
                    count+=6;
                }
            }

            totalBool[SIXES]=true;
            return count;
        }
        else if(row == THREE_OF_KIND){ // two loops to read and figure out if three die match
            int sameDie;
            for(i = 0; i < HAND_SIZE; i++){
                sameDie =1;
                for(j=0; j < HAND_SIZE; j++){
                    if((hand->getDice(i)->reveal()== hand->getDice(j)->reveal())&& (i!=j)){
                        sameDie++;
                    }
                }
                if(sameDie >=3){
                    for(int k = 0; k < HAND_SIZE; k++){
                        count += hand->getDice(k)->reveal();
                    }
                    break;
                }
            }
            totalBool[THREE_OF_KIND] = true;
            return count;
        }
        else if(row == FOUR_OF_KIND){ // two loops to read and figure out if four die match
            int sameDie;
            for(i = 0; i < HAND_SIZE; i++){
                sameDie =1;
                for(j=0; j < HAND_SIZE; j++){
                    if((hand->getDice(i)->reveal()== hand->getDice(j)->reveal())&& (i!=j)){
                        sameDie++;
                    }
                }
                if(sameDie >=4){
                    for(int k = 0; k < HAND_SIZE; k++){
                        count += hand->getDice(k)->reveal();
                    }
                    break;
                }
            }
            totalBool[FOUR_OF_KIND] = true;
            return count;
        }
        else if(row == FULL_HOUSE){ // two loops to read and figure out if three die match and if their is a pair for full house
            bool two =false;
            bool three = false;
            int sameDie;
            for(i = 0; i < HAND_SIZE; i++){
                sameDie = 1;
                for(j=0; j < HAND_SIZE; j++){
                    if((hand->getDice(i)->reveal()== hand->getDice(j)->reveal()) &&(i!=j)){
                        sameDie++;
                    }

                }
                if(sameDie==2){
                    two = true;
                }
                else if(sameDie == 3){
                    three = true;
                }
                else if(sameDie ==5){
                    two =true;
                    three = true;
                }
            }
            if(two&&three){
                count = 25;
            }
            totalBool[FULL_HOUSE] = true;
            return count;
        }
        else if (row == SMALL_STRAIGHT){ //loops through a dice array and looks for the three instances in which a small straight exists
            totalBool[SMALL_STRAIGHT] = true;
            int array[6] = {0,0,0,0,0,0};
            for(int i = 0; i < HAND_SIZE; i++){
                array[hand->getDice(i)->reveal()-1]++;
            }
            if(array[0] >=1 && array[1]>=1 && array[2] >=1 && array[3]>=1){
                return 30;
            }
            else if(array[1] >=1 && array[2]>=1 && array[3] >=1 && array[4]>=1){
                return 30;
            }
            else if(array[2] >=1 && array[3]>=1 && array[4] >=1 && array[5]>=1){
                return 30;
            }
            return 0;
        }
        else if(row == LARGE_STRAIGHT){ //loops through a dice array and looks for the two instances in which a large straight exists
            totalBool[LARGE_STRAIGHT]= true;
            int array[6] = {0,0,0,0,0,0};
            for(int i = 0; i < HAND_SIZE; i++){
                array[hand->getDice(i)->reveal()-1]++;
            }
            if(array[0] >=1 && array[1]>=1 && array[2] >=1 && array[3]>=1 && array[4] >= 1){
                return 40;
            }
            else if(array[1] >=1 && array[2]>=1 && array[3] >=1 && array[4]>=1 && array[5]>=1){
                return 40;
            }
        }
        else if(row == CHANCE){ // loops through the die array and adds them all up
            totalBool[CHANCE] = true;
            int totalPoints = 0;
            for(int i = 0; i < HAND_SIZE; i++){
                int diceVal = hand->getDice(i)->reveal();
                totalPoints += diceVal;
            }
            return totalPoints;
        }
        else if (row == YAHTZEE){ // loops through die array to see if all the die match
            totalBool[YAHTZEE] = true;
            int array[6] = {0,0,0,0,0,0};
            for(int i = 0; i < HAND_SIZE; i++){
                array[hand->getDice(i)->reveal()-1]++;
            }
            for(int i = 0; i < 6; i++){
                if(array[i]==5){
                    return 50;
                }

            }
            return 0;
        }
        return 0;

    }


    //Display the board
    void show(){
        cout << "Select a combination to play: " << endl;
        cout << "1.  Ones:         " << endl;
        cout << "2.  Twos:         " << endl;
        cout << "3.  Threes:       " << endl;
        cout << "4.  Fours:        " << endl;
        cout << "5.  Fives:        " << endl;
        cout << "6.  Sixes:        " << endl;
        cout << "    Sum:          " << endl;
        cout << "    Bonus:        " << endl;
        cout << "7.  Three of a kind:  "<< endl;
        cout << "8.  Four of a kind:   "<< endl;
        cout << "9.  Full house:   " << endl;
        cout << "10. Small straight:    " << endl;
        cout << "11. Large straight:    "<< endl;
        cout << "12. Chance:       "<< endl;
        cout << "13. Yahtzee:      "<< endl;
    }


    //Returns the score of the upper part of the board
    int getUpperScore(){
        return (total[ONES]+total[TWOS]+total[THREES]+total[FOURS]+total[FIVES]+total[SIXES]);
    }

    //Returns the score of the lower part of the board
    int getLowerScore(){
        return (total[THREE_OF_KIND]+total[FOUR_OF_KIND]+total[FULL_HOUSE]+total[SMALL_STRAIGHT]+total[LARGE_STRAIGHT]+total[CHANCE]+total[YAHTZEE]);
    }


    //Returns the bonus points
    int getBonusScore(){
        if (getUpperScore() >=63){
            return 35;
        }
        return 0;
    }

    //Returns the total score
    int getTotalScore(){
        return getLowerScore() + getUpperScore()+getBonusScore();
    }

    //Play a hand based on the selected row
    void play(Hand* hand, int row){
        int score = calcScore(hand, row);
        total[row] = score;

    }

    bool isFinished(){
        for(int i = 0; i< BOARD_SIZE; i++){
            if(totalBool[i] != true){
                return false;
            }

        }
        return true;
    }

    bool isPlayed(int row){
        return totalBool[row];
    }


};


//Check to see if a row has been played or not (returns true if a row has been played)



//Check to see if all rows haven been played or not (returns true if all rows have been played)



//#######################################################################################

//The run function is the main loop of your program
void run() {
    Game game;
    Hand* hand = new Hand();
    // hand->getDice(0)->setValue(1);
    // hand->getDice(1)->setValue(2);
    // hand->getDice(2)->setValue(3);
    // hand->getDice(3)->setValue(4);
    // hand->getDice(4)->setValue(5);
    while(!game.isFinished()){
        int diceRow = 0;
        string constDie = "";
        for(int i = 0; i < 3; i++){
            hand->play();
            hand->show();
            cout << "Keep Dice(s to stop rolling)";
            cin >> constDie;

            if(constDie == "s"){
                break;
            }
            hand->setSelection(constDie);

        }
        cout << "Choose a combination to play ";
        cin >> diceRow;
        game.play(hand, diceRow);
        game.show();
        break;
    }

}


//For these types of programs there exists many combinations that you might have missed.
//The best way to check them all is to write test cases for your program.
//Here I give you an example of checking large straight. You can design your own test cases for different parts.

void test_case() {
    Game game;
    Hand* hand = new Hand();
    hand->getDice(0)->setValue(1);
    hand->getDice(1)->setValue(1);
    hand->getDice(2)->setValue(1);
    hand->getDice(3)->setValue(1);
    hand->getDice(4)->setValue(1);

    bool check1 = false;
    if (game.calcScore(hand, FULL_HOUSE) == 0) {
        check1 = true;
    }
    if (check1) {
        cout << "check 1 passed\n";
    }};
/*
    hand->getDice(0)->setValue(2);
    hand->getDice(1)->setValue(6);
    hand->getDice(2)->setValue(4);
    hand->getDice(3)->setValue(3);
    hand->getDice(4)->setValue(5);

    bool check2 = true;
    if (game.calcScore(hand, LARGE_STRAIGHT) != 40) {
        check2 = false;
    }

    if (check2) {
        cout << "check 2 passed\n";
    }

    hand->getDice(0)->setValue(3);
    hand->getDice(1)->setValue(2);
    hand->getDice(2)->setValue(5);
    hand->getDice(3)->setValue(6);
    hand->getDice(4)->setValue(3);

    bool check3 = true;
    if (game.calcScore(hand, LARGE_STRAIGHT) != 0) {
        check3 = false;
    }

    if (check3) {
        cout << "check 3 passed\n";
    }

    hand->getDice(0)->setValue(1);
    hand->getDice(1)->setValue(2);
    hand->getDice(2)->setValue(3);
    hand->getDice(3)->setValue(4);
    hand->getDice(4)->setValue(6);

    bool check4 = true;
    if (game.calcScore(hand, LARGE_STRAIGHT) != 0) {
        check4 = false;
    }

    if (check4) {
        cout << "check 4 passed\n";
    }


}
*/
// THE AUTOGRADER WILL REPLACE THE MAIN FUNCTION.
// DO NOT ADD ANY LOGIC OF YOUR PROGRAM HERE.
int main() {

    srand(time(0));
    run();
    //test_case();
    return 0;
}